#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>
#include <limits>
#include <cmath>
#include <cstdlib>

using namespace std;

// Infinity constant safe from addition overflow
const long long INF = numeric_limits<long long>::max() / 4;
// Configurable Pre-emption threshold (default 50)
const int PREEMPTION_LIMIT = 50;

// INTERSECTION COORDINATES FOR SPATIAL HEADING CALCULATION
struct Intersection {
    int id;
    string name;
    double x; // Grid X (e.g. meters or grid units)
    double y; // Grid Y
};

// ROAD STRUCTURE
struct Road {
    int id;
    int from;
    int to;
    int cost;
    bool blocked;
};

// ADJACENCY EDGE FOR FAST DIJKSTRA
struct Edge {
    int to;
    int cost;
    int roadIndex;
};

// EMERGENCY VEHICLE REQUEST
struct EmergencyRequest {
    int requestId;
    string vehicleName;
    int vehicleType; // 1: Ambulance, 2: Fire Brigade, 3: Police
    int urgency;     // 1 to 5
    int priorityScore;
    int start;
    int destination;
};

// HIGHER PRIORITY REQUESTS ARE PROCESSED FIRST (Max-Heap with FIFO Tie-Breaking)
struct HigherPriorityFirst {
    bool operator()(const EmergencyRequest &a, const EmergencyRequest &b) const {
        if (a.priorityScore == b.priorityScore) {
            // Smaller request ID was created first -> processed first
            return a.requestId > b.requestId;
        }
        return a.priorityScore < b.priorityScore;
    }
};

// SAFE INTEGER INPUT WITH STREAM RECOVERY
int readInt(const string &prompt) {
    int value;
    while (true) {
        cout << prompt;
        if (cin >> value) {
            return value;
        }
        if (cin.eof()) {
            cout << "\nInput ended. Exiting safely.\n";
            exit(0);
        }
        cout << "Invalid input. Please enter an integer.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

// VEHICLE TYPE NAME (5 Classes)
string vehicleTypeName(int type) {
    switch (type) {
        case 1: return "Ambulance";
        case 2: return "Fire Pumper";
        case 3: return "Police Cruiser";
        case 4: return "Aerial Ladder";
        case 5: return "SWAT BearCat";
        default: return "Emergency Vehicle";
    }
}

// SPATIAL DIRECTION CALCULATION BASED ON NODE COORDINATES
string calculateApproachDirection(const Intersection &fromNode, const Intersection &toNode) {
    double dx = toNode.x - fromNode.x;
    double dy = toNode.y - fromNode.y;

    if (abs(dx) < 1e-6 && abs(dy) < 1e-6) return "Unknown";

    // Angle in degrees: 0 = East, 90 = North, 180 = West, -90/270 = South
    double angleDeg = atan2(dy, dx) * 180.0 / 3.14159265358979323846;
    if (angleDeg < 0) angleDeg += 360.0;

    // Vehicle approaching toNode from fromNode
    // An approach from the West means vehicle moves Eastward (angle around 0)
    if (angleDeg >= 315 || angleDeg < 45) return "West Approach (Moving East)";
    if (angleDeg >= 45 && angleDeg < 135) return "South Approach (Moving North)";
    if (angleDeg >= 135 && angleDeg < 225) return "East Approach (Moving West)";
    return "North Approach (Moving South)";
}

// PRIORITY SCORE CALCULATION WITH BALANCED URGENCY CURVE
int calculatePriorityScore(int vehicleType, int urgency) {
    int bonus;
    if (vehicleType == 1) bonus = 30;      // Ambulance
    else if (vehicleType == 4) bonus = 25; // Aerial Ladder
    else if (vehicleType == 2) bonus = 20; // Fire Pumper
    else if (vehicleType == 5) bonus = 15; // SWAT BearCat
    else bonus = 10;                       // Police Cruiser

    // Urgency scaled 1 to 5
    return (urgency * 10) + bonus;
}

// DISPLAY ALL ROADS
void displayRoads(const vector<Road> &roads) {
    cout << "\n========== ROAD NETWORK STATUS ==========\n";
    if (roads.empty()) {
        cout << "No roads currently configured in network.\n";
        return;
    }
    for (size_t i = 0; i < roads.size(); i++) {
        cout << "Road [" << i << "]: Intersection "
             << roads[i].from << " <---> Intersection "
             << roads[i].to
             << " | Travel Cost: " << roads[i].cost
             << " | Status: "
             << (roads[i].blocked ? "[BLOCKED - NO TRAFFIC]" : "[OPEN - PASSABLE]")
             << '\n';
    }
}

// EFFICIENT DIJKSTRA SHORTEST-PATH USING ADJACENCY LIST
// Solves Bug 1 (O(V * E) -> O((V + E) log V))
// Solves Bug 2 (Parallel edges properly supported)
// Solves Bug 3 (Start == destination handled cleanly)
vector<int> findRoute(
    int nodes,
    const vector<Road> &roads,
    int start,
    int destination,
    long long &totalCost
) {
    totalCost = -1;

    if (start < 0 || start >= nodes || destination < 0 || destination >= nodes) {
        return {};
    }

    if (start == destination) {
        totalCost = 0;
        return {start};
    }

    // Build Adjacency List
    vector<vector<Edge>> adj(nodes);
    for (size_t i = 0; i < roads.size(); i++) {
        if (!roads[i].blocked) {
            adj[roads[i].from].push_back({roads[i].to, roads[i].cost, static_cast<int>(i)});
            adj[roads[i].to].push_back({roads[i].from, roads[i].cost, static_cast<int>(i)});
        }
    }

    vector<long long> distance(nodes, INF);
    vector<int> previous(nodes, -1);

    priority_queue<
        pair<long long, int>,
        vector<pair<long long, int>>,
        greater<pair<long long, int>>
    > pq;

    distance[start] = 0;
    pq.push({0, start});

    while (!pq.empty()) {
        long long currentCost = pq.top().first;
        int u = pq.top().second;
        pq.pop();

        if (currentCost > distance[u]) continue;
        if (u == destination) break;

        for (const auto &edge : adj[u]) {
            int v = edge.to;
            long long newCost = distance[u] + edge.cost;

            if (newCost < distance[v]) {
                distance[v] = newCost;
                previous[v] = u;
                pq.push({newCost, v});
            }
        }
    }

    if (distance[destination] == INF) {
        return {}; // No route available
    }

    // Reconstruct path
    vector<int> route;
    for (int curr = destination; curr != -1; curr = previous[curr]) {
        route.push_back(curr);
    }
    reverse(route.begin(), route.end());
    totalCost = distance[destination];
    return route;
}

// DISPLAY ROUTE IN CLEAN FORMAT
void displayRoute(const vector<int> &route, long long cost) {
    if (route.empty()) {
        cout << "[ROUTE ALERT] No passable route is currently available.\n";
        return;
    }
    cout << "Optimal Emergency Route: ";
    for (size_t i = 0; i < route.size(); i++) {
        cout << route[i];
        if (i + 1 < route.size()) cout << " -> ";
    }
    cout << " | Total Travel Cost: " << cost << '\n';
}

// AUTOMATIC TRAFFIC SIGNAL PRE-EMPTION
// Solves Bug 4: Computes actual approach vector and activates for current hop
void simulateSignalPreemption(
    int priorityScore,
    int fromNode,
    int toNode,
    const vector<Intersection> &intersections
) {
    cout << "\n--- [SIGNAL PRE-EMPTION ACTUATOR at Intersection " << toNode << "] ---\n";
    cout << "Incoming Vehicle Priority Score: " << priorityScore << " (Threshold: " << PREEMPTION_LIMIT << ")\n";

    if (priorityScore < PREEMPTION_LIMIT) {
        cout << "[PRE-EMPTION STATUS] Normal Signal Cycle Retained. Priority threshold not reached.\n";
        return;
    }

    string approach = "Approaching Node " + to_string(toNode);
    if (fromNode >= 0 && fromNode < (int)intersections.size() &&
        toNode >= 0 && toNode < (int)intersections.size()) {
        approach = calculateApproachDirection(intersections[fromNode], intersections[toNode]);
    }

    cout << "[PRE-EMPTION ENGAGED] Corridor Pre-emption Active!\n";
    cout << "-> Incoming Approach Corridor: " << approach << " -> FORCED GREEN LIGHT\n";
    cout << "-> Conflicting Cross-Traffic Approaches: FORCED RED LIGHT (Clearance interval executed)\n";
    cout << "-> Emergency Strobe Sensor: TRIGGERED\n";
}

// ROAD UPDATE & DYNAMIC RE-ROUTING
bool updateRoadsAndReroute(
    int nodes,
    vector<Road> &roads,
    int currentLocation,
    int destination,
    vector<int> &currentRoute,
    long long &routeCost
) {
    cout << "\n========== ROAD MANAGEMENT CONSOLE ==========\n";
    cout << "1. Adjust Road Travel Cost (Simulate Traffic / Congestion)\n";
    cout << "2. Block Road (Simulate Accident / Roadblock / Flood)\n";
    cout << "3. Reopen Road\n";
    cout << "4. View All Roads\n";
    cout << "0. Return to Navigation\n";
    cout << "Current Location: " << currentLocation << " | Target Destination: " << destination << '\n';

    int choice = readInt("Select action: ");
    if (choice == 0) return true;

    if (choice == 4) {
        displayRoads(roads);
        return true;
    }

    if (choice < 1 || choice > 3) {
        cout << "Invalid choice.\n";
        return true;
    }

    if (roads.empty()) {
        cout << "No roads in network.\n";
        return true;
    }

    displayRoads(roads);
    int index = readInt("Enter road index [0 to " + to_string(roads.size() - 1) + "]: ");
    if (index < 0 || index >= static_cast<int>(roads.size())) {
        cout << "Invalid road index.\n";
        return true;
    }

    if (choice == 1) {
        int newCost = readInt("Enter new road cost (> 0): ");
        if (newCost <= 0) {
            cout << "Cost must be strictly positive.\n";
            return true;
        }
        roads[index].cost = newCost;
        cout << "Road [" << index << "] cost updated to " << newCost << ".\n";
    } else if (choice == 2) {
        if (roads[index].blocked) {
            cout << "Road [" << index << "] is already blocked.\n";
        } else {
            roads[index].blocked = true;
            cout << "Road [" << index << "] is now BLOCKED.\n";
        }
    } else if (choice == 3) {
        if (!roads[index].blocked) {
            cout << "Road [" << index << "] is already open.\n";
        } else {
            roads[index].blocked = false;
            cout << "Road [" << index << "] is now REOPENED.\n";
        }
    }

    // Always recalculate after road changes (Fixes Bug 6)
    long long newCost;
    vector<int> newRoute = findRoute(nodes, roads, currentLocation, destination, newCost);

    if (newRoute.empty()) {
        currentRoute.clear();
        routeCost = -1;
        cout << "[WARNING] No available path from node " << currentLocation << " to " << destination << "!\n";
        cout << "Vehicle holds at intersection " << currentLocation << ". Modify road network to recover.\n";
        return false;
    }

    bool changed = (newRoute != currentRoute);
    currentRoute = newRoute;
    routeCost = newCost;

    if (changed) {
        cout << "\n[DYNAMIC REROUTE SUCCESSFUL] New optimal corridor calculated:\n";
    } else {
        cout << "\nCurrent route remains optimal despite the modification:\n";
    }
    displayRoute(currentRoute, routeCost);
    return true;
}

// COMPREHENSIVE AUTOMATED TEST SUITE
void runRouteTest() {
    cout << "\n============================================\n";
    cout << "       COMPREHENSIVE BUILT-IN TESTS\n";
    cout << "============================================\n";

    vector<Road> testRoads = {
        {0, 0, 1, 2, false},
        {1, 1, 2, 3, false},
        {2, 2, 3, 4, false},
        {3, 0, 3, 20, false}
    };

    long long cost;
    vector<int> route = findRoute(4, testRoads, 0, 3, cost);
    bool test1 = (!route.empty() && cost == 9);
    cout << "Test 1 [Shortest Path 0->1->2->3 Cost 9]: " << (test1 ? "PASS" : "FAIL") << '\n';

    // Test 2: Reroute upon road closure
    testRoads[1].blocked = true; // block 1-2
    route = findRoute(4, testRoads, 0, 3, cost);
    bool test2 = (!route.empty() && cost == 20 && route.size() == 2);
    cout << "Test 2 [Alternate Highway 0->3 Cost 20]: " << (test2 ? "PASS" : "FAIL") << '\n';

    // Test 3: Total disconnection detection
    testRoads[3].blocked = true; // block 0-3
    route = findRoute(4, testRoads, 0, 3, cost);
    bool test3 = (route.empty() && cost == -1);
    cout << "Test 3 [Disconnected Graph Recovery Detection]: " << (test3 ? "PASS" : "FAIL") << '\n';

    // Test 4: Mid-transit current position routing
    testRoads[1].blocked = false;
    testRoads[3].blocked = false;
    route = findRoute(4, testRoads, 2, 3, cost);
    bool test4 = (!route.empty() && route.front() == 2 && route.back() == 3 && cost == 4);
    cout << "Test 4 [Mid-Route Subpath 2->3 Cost 4]: " << (test4 ? "PASS" : "FAIL") << '\n';

    // Test 5: Identical start and destination
    route = findRoute(4, testRoads, 1, 1, cost);
    bool test5 = (route.size() == 1 && route[0] == 1 && cost == 0);
    cout << "Test 5 [Start == Destination Zero-Cost Base Case]: " << (test5 ? "PASS" : "FAIL") << '\n';

    // Test 6: Priority Queue Ordering Check
    priority_queue<EmergencyRequest, vector<EmergencyRequest>, HigherPriorityFirst> pq;
    pq.push({1, "Police", 3, 1, calculatePriorityScore(3, 1), 0, 3});       // Score: 10 + 10 = 20
    pq.push({2, "Fire Brigade", 2, 4, calculatePriorityScore(2, 4), 0, 3}); // Score: 40 + 20 = 60
    pq.push({3, "Ambulance", 1, 3, calculatePriorityScore(1, 3), 0, 3});    // Score: 30 + 30 = 60
    
    // Higher priority score 60 comes first. Among score 60, Fire (id 2) was pushed before Ambulance (id 3).
    EmergencyRequest r1 = pq.top(); pq.pop();
    EmergencyRequest r2 = pq.top(); pq.pop();
    EmergencyRequest r3 = pq.top(); pq.pop();
    bool test6 = (r1.priorityScore == 60 && r1.requestId == 2 &&
                  r2.priorityScore == 60 && r2.requestId == 3 &&
                  r3.priorityScore == 20);
    cout << "Test 6 [Priority Queue Score & FIFO Tie-Break]: " << (test6 ? "PASS" : "FAIL") << '\n';

    cout << "--------------------------------------------\n";
    bool allPass = test1 && test2 && test3 && test4 && test5 && test6;
    cout << "ALL VERIFICATION CHECKS: " << (allPass ? "ALL TESTS PASSED [100%]" : "SOME TESTS FAILED") << "\n\n";
}

// MAIN ENTRY POINT
int main() {
    cout << "========================================================\n";
    cout << "   URBAN EMERGENCY PRE-EMPTION ENGINE (UEPE) - C++ CORE\n";
    cout << "   Intelligent Traffic Signal Pre-emption & Rerouting   \n";
    cout << "========================================================\n";

    // Run verification first
    runRouteTest();

    int nodes;
    do {
        nodes = readInt("Enter number of intersections (1-100): ");
        if (nodes < 1 || nodes > 100) cout << "Value must be between 1 and 100.\n";
    } while (nodes < 1 || nodes > 100);

    // Setup intersection coordinates for directional calculations
    vector<Intersection> intersections(nodes);
    for (int i = 0; i < nodes; i++) {
        intersections[i].id = i;
        intersections[i].name = "Junction " + to_string(i);
        // Default grid placement: arrange in pseudo grid
        int gridWidth = max(1, (int)sqrt(nodes));
        intersections[i].x = (i % gridWidth) * 100.0;
        intersections[i].y = (i / gridWidth) * 100.0;
    }

    int roadCount;
    do {
        roadCount = readInt("Enter number of roads (0-10000): ");
        if (roadCount < 0 || roadCount > 10000) cout << "Value must be between 0 and 10000.\n";
    } while (roadCount < 0 || roadCount > 10000);

    vector<Road> roads;
    for (int i = 0; i < roadCount; i++) {
        cout << "\nEnter Road [" << i << "] specifications:\n";
        int from = readInt("From intersection ID: ");
        int to = readInt("To intersection ID: ");
        int cost = readInt("Travel Cost (travel time/distance > 0): ");

        if (from < 0 || from >= nodes || to < 0 || to >= nodes || from == to || cost <= 0) {
            cout << "Invalid road parameters. Please re-enter.\n";
            i--;
            continue;
        }
        roads.push_back({i, from, to, cost, false});
    }

    displayRoads(roads);

    int requestCount;
    do {
        requestCount = readInt("\nNumber of Emergency Vehicle Requests to simulate: ");
        if (requestCount < 0 || requestCount > 1000) cout << "Value must be between 0 and 1000.\n";
    } while (requestCount < 0 || requestCount > 1000);

    priority_queue<EmergencyRequest, vector<EmergencyRequest>, HigherPriorityFirst> requestQueue;

    for (int i = 0; i < requestCount; i++) {
        cout << "\n--- Emergency Request Dispatch [" << i + 1 << "] ---\n";
        int type = readInt("Vehicle Type (1: Ambulance, 2: Fire Brigade, 3: Police): ");
        int urgency = readInt("Urgency Severity (1: Low to 5: Critical): ");
        int start = readInt("Dispatch Origin Intersection (0 to " + to_string(nodes - 1) + "): ");
        int dest = readInt("Target Destination Intersection (0 to " + to_string(nodes - 1) + "): ");

        if (type < 1 || type > 3 || urgency < 1 || urgency > 5 ||
            start < 0 || start >= nodes || dest < 0 || dest >= nodes) {
            cout << "Invalid request specifications. Re-enter.\n";
            i--;
            continue;
        }

        EmergencyRequest req;
        req.requestId = i + 1;
        req.vehicleType = type;
        req.urgency = urgency;
        req.vehicleName = vehicleTypeName(type);
        req.start = start;
        req.destination = dest;
        req.priorityScore = calculatePriorityScore(type, urgency);

        cout << "Dispatched: " << req.vehicleName << " | Priority Score: " << req.priorityScore
             << " (Pre-emption: " << (req.priorityScore >= PREEMPTION_LIMIT ? "ELIGIBLE" : "STANDARD") << ")\n";

        requestQueue.push(req);
    }

    cout << "\n============================================\n";
    cout << "   DISPATCHING EMERGENCY MISSIONS BY PRIORITY\n";
    cout << "============================================\n";

    while (!requestQueue.empty()) {
        EmergencyRequest req = requestQueue.top();
        requestQueue.pop();

        cout << "\n======================================================\n";
        cout << "ACTIVE MISSION: " << req.vehicleName << " (Priority Score: " << req.priorityScore << ")\n";
        cout << "From Junction " << req.start << " ---> Destination Junction " << req.destination << '\n';
        cout << "======================================================\n";

        int currentLocation = req.start;
        long long routeCost;
        vector<int> currentRoute = findRoute(nodes, roads, currentLocation, req.destination, routeCost);
        displayRoute(currentRoute, routeCost);

        if (currentLocation == req.destination) {
            cout << "Vehicle is already at destination.\n";
            continue;
        }

        bool missionEnded = false;

        while (currentLocation != req.destination && !missionEnded) {
            cout << "\n--- In-Transit Telemetry ---\n";
            cout << "Current Location: " << currentLocation << " | Destination: " << req.destination << '\n';
            if (currentRoute.size() >= 2) {
                cout << "Next Waypoint: Junction " << currentRoute[1] << '\n';
            }
            cout << "1. Advance to Next Intersection\n";
            cout << "2. Adjust Traffic / Congestion / Block / Reopen Road\n";
            cout << "3. Display Roads & Current Route\n";
            cout << "4. Abort Mission Simulation\n";

            int choice = readInt("Command: ");

            if (choice == 1) {
                if (currentRoute.size() < 2) {
                    cout << "No viable route available. Adjust road network first.\n";
                    continue;
                }

                int nextLocation = currentRoute[1];

                // Trigger real-time directional pre-emption at upcoming intersection
                simulateSignalPreemption(req.priorityScore, currentLocation, nextLocation, intersections);

                currentLocation = nextLocation;
                cout << ">>> Vehicle arrived at Intersection " << currentLocation << ".\n";

                if (currentLocation == req.destination) {
                    cout << "\n*** SUCCESS: " << req.vehicleName << " ARRIVED AT DESTINATION! ***\n";
                    break;
                }

                // Recalculate remaining path from current location
                currentRoute = findRoute(nodes, roads, currentLocation, req.destination, routeCost);
                displayRoute(currentRoute, routeCost);

                if (currentRoute.empty()) {
                    cout << "[ALERT] Remaining path obstructed! Vehicle held at Junction " << currentLocation << ".\n";
                }
            } else if (choice == 2) {
                updateRoadsAndReroute(nodes, roads, currentLocation, req.destination, currentRoute, routeCost);
            } else if (choice == 3) {
                displayRoads(roads);
                displayRoute(currentRoute, routeCost);
            } else if (choice == 4) {
                cout << "Mission simulation terminated by operator.\n";
                missionEnded = true;
            } else {
                cout << "Invalid choice. Select 1 to 4.\n";
            }
        }
    }

    cout << "\n============================================\n";
    cout << "   ALL EMERGENCY DISPATCHES COMPLETED\n";
    cout << "============================================\n";
    return 0;
}
