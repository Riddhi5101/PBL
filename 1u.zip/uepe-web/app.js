/**
 * URBAN EMERGENCY PRE-EMPTION ENGINE (UEPE) - 3D WEB APPLICATION
 * NextGen Intelligent Traffic Management System (ITMS)
 * 
 * Architecture:
 * - City3DRenderer: Hardware-Accelerated WebGL 3D City Simulation (Three.js)
 * - DijkstraRouter: High-Performance Graph Routing with Adjacency List (O((V+E)log V))
 * - SignalPreemptionManager: Spatial Vector-Based Traffic Signal Actuation
 * - Multi-Vehicle Priority Fleet & Conflict Arbitration
 * - Dynamic Mid-Transit Obstruction Rerouting
 * - Web Audio API Sound Synthesizer
 * - Automated Unit Test Verification Suite
 */

// ============================================================================
// AUDIO SYNTHESIZER (Web Audio API)
// ============================================================================
class SoundEffects {
  constructor() {
    this.ctx = null;
    this.enabled = true;
  }

  initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
  }

  playDispatchChirp() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(1400, now + 0.08);
      osc.frequency.setValueAtTime(900, now + 0.1);
      osc.frequency.exponentialRampToValueAtTime(1600, now + 0.18);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.22);
    } catch (e) { console.warn(e); }
  }

  playSirenYelp() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(650, now);
      osc.frequency.linearRampToValueAtTime(1100, now + 0.15);
      osc.frequency.linearRampToValueAtTime(700, now + 0.3);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.32);
    } catch (e) { console.warn(e); }
  }

  playAlertKlaxon() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.setValueAtTime(330, now + 0.12);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.3);
    } catch (e) { console.warn(e); }
  }

  playArrivalChime() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.50]; // C E G C
      notes.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.1, now + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.25);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.26);
      });
    } catch (e) { console.warn(e); }
  }
}

// ============================================================================
// GRAPH ROUTING ENGINE (Dijkstra Shortest Path with Adjacency List)
// ============================================================================
class DijkstraRouter {
  /**
   * Solves Bug 1: Adjacency List reduces traversal from O(V*E) to O((V+E) log V).
   * Solves Bug 2: Proper bidirectional and parallel multigraph support.
   * Solves Bug 3: startId === destId handled cleanly as base case.
   */
  static findRoute(nodes, roads, startId, destId) {
    if (startId === destId) {
      return { route: [startId], totalCost: 0, roadPath: [] };
    }

    const nodeIds = new Set(nodes.map(n => n.id));
    if (!nodeIds.has(startId) || !nodeIds.has(destId)) {
      return { route: [], totalCost: -1, roadPath: [] };
    }

    // Build Adjacency List
    const adj = new Map();
    nodes.forEach(n => adj.set(n.id, []));

    roads.forEach(r => {
      if (!r.blocked && r.cost > 0) {
        adj.get(r.from)?.push({ to: r.to, cost: r.cost, roadId: r.id });
        adj.get(r.to)?.push({ to: r.from, cost: r.cost, roadId: r.id });
      }
    });

    const dist = new Map();
    const prevNode = new Map();
    const prevRoad = new Map();
    nodes.forEach(n => dist.set(n.id, Infinity));

    const pq = [];
    dist.set(startId, 0);
    pq.push({ id: startId, cost: 0 });

    while (pq.length > 0) {
      pq.sort((a, b) => a.cost - b.cost);
      const { id: u, cost: currentCost } = pq.shift();

      if (currentCost > dist.get(u)) continue;
      if (u === destId) break;

      const neighbors = adj.get(u) || [];
      for (const edge of neighbors) {
        const v = edge.to;
        const newCost = dist.get(u) + edge.cost;
        if (newCost < dist.get(v)) {
          dist.set(v, newCost);
          prevNode.set(v, u);
          prevRoad.set(v, edge.roadId);
          pq.push({ id: v, cost: newCost });
        }
      }
    }

    if (dist.get(destId) === Infinity) {
      return { route: [], totalCost: -1, roadPath: [] };
    }

    // Reconstruct Path
    const route = [];
    const roadPath = [];
    let curr = destId;
    while (curr !== undefined && curr !== null) {
      route.push(curr);
      if (prevRoad.has(curr)) {
        roadPath.push(prevRoad.get(curr));
      }
      curr = prevNode.get(curr);
    }
    route.reverse();
    roadPath.reverse();

    return { route, totalCost: dist.get(destId), roadPath };
  }
}

// ============================================================================
// MAP PRESET CONFIGURATIONS
// ============================================================================
const MAP_PRESETS = {
  downtown: {
    name: "Downtown Metro (8 Nodes)",
    nodes: [
      { id: 0, name: "City Trauma Center", x: 120, y: 150 },
      { id: 1, name: "Civic Plaza", x: 340, y: 150 },
      { id: 2, name: "North Arterial", x: 560, y: 150 },
      { id: 3, name: "Tech District", x: 230, y: 320 },
      { id: 4, name: "Downtown Grand Junction", x: 450, y: 320 },
      { id: 5, name: "Central Fire Station 1", x: 120, y: 490 },
      { id: 6, name: "East Metro Transit", x: 340, y: 490 },
      { id: 7, name: "Police HQ Precinct 4", x: 560, y: 490 }
    ],
    roads: [
      { id: 0, from: 0, to: 1, cost: 5, blocked: false },
      { id: 1, from: 1, to: 2, cost: 6, blocked: false },
      { id: 2, from: 0, to: 3, cost: 8, blocked: false },
      { id: 3, from: 1, to: 4, cost: 7, blocked: false },
      { id: 4, from: 2, to: 4, cost: 9, blocked: false },
      { id: 5, from: 3, to: 4, cost: 4, blocked: false },
      { id: 6, from: 3, to: 5, cost: 6, blocked: false },
      { id: 7, from: 4, to: 6, cost: 5, blocked: false },
      { id: 8, from: 4, to: 7, cost: 8, blocked: false },
      { id: 9, from: 5, to: 6, cost: 7, blocked: false },
      { id: 10, from: 6, to: 7, cost: 6, blocked: false },
      { id: 11, from: 1, to: 3, cost: 5, blocked: false }
    ]
  },
  river: {
    name: "River Choke-Point (6 Nodes)",
    nodes: [
      { id: 0, name: "North Hospital", x: 160, y: 160 },
      { id: 1, name: "North Industrial Park", x: 520, y: 160 },
      { id: 2, name: "West Suspension Bridge", x: 220, y: 320 },
      { id: 3, name: "East Causeway Bridge", x: 460, y: 320 },
      { id: 4, name: "South Waterfront", x: 160, y: 480 },
      { id: 5, name: "South Valley Precinct", x: 520, y: 480 }
    ],
    roads: [
      { id: 0, from: 0, to: 1, cost: 8, blocked: false },
      { id: 1, from: 0, to: 2, cost: 4, blocked: false },
      { id: 2, from: 1, to: 3, cost: 5, blocked: false },
      { id: 3, from: 2, to: 3, cost: 12, blocked: false },
      { id: 4, from: 2, to: 4, cost: 6, blocked: false }, // West Bridge
      { id: 5, from: 3, to: 5, cost: 7, blocked: false }, // East Bridge
      { id: 6, from: 4, to: 5, cost: 9, blocked: false }
    ]
  },
  cpp_test: {
    name: "Original C++ 4-Node Test Graph",
    nodes: [
      { id: 0, name: "Intersection 0 (Origin)", x: 150, y: 320 },
      { id: 1, name: "Intersection 1 (North Waypoint)", x: 340, y: 180 },
      { id: 2, name: "Intersection 2 (East Waypoint)", x: 530, y: 180 },
      { id: 3, name: "Intersection 3 (Destination)", x: 530, y: 420 }
    ],
    roads: [
      { id: 0, from: 0, to: 1, cost: 2, blocked: false },  // 0 -> 1: 2
      { id: 1, from: 1, to: 2, cost: 3, blocked: false },  // 1 -> 2: 3
      { id: 2, from: 2, to: 3, cost: 4, blocked: false },  // 2 -> 3: 4 (Total: 9)
      { id: 3, from: 0, to: 3, cost: 20, blocked: false }  // 0 -> 3: 20 (Direct Highway)
    ]
  },
  grid: {
    name: "Arterial Grid (12 Nodes)",
    nodes: [
      { id: 0, name: "Hospital", x: 120, y: 140 },
      { id: 1, name: "Civic 1", x: 280, y: 140 },
      { id: 2, name: "Arterial 2", x: 440, y: 140 },
      { id: 3, name: "Station 3", x: 600, y: 140 },
      { id: 4, name: "West Gate", x: 120, y: 310 },
      { id: 5, name: "Central Plaza", x: 280, y: 310 },
      { id: 6, name: "Commerce 6", x: 440, y: 310 },
      { id: 7, name: "Fire HQ 7", x: 600, y: 310 },
      { id: 8, name: "South Hub", x: 120, y: 480 },
      { id: 9, name: "Market 9", x: 280, y: 480 },
      { id: 10, name: "Transit 10", x: 440, y: 480 },
      { id: 11, name: "Police Precinct", x: 600, y: 480 }
    ],
    roads: [
      { id: 0, from: 0, to: 1, cost: 4, blocked: false },
      { id: 1, from: 1, to: 2, cost: 5, blocked: false },
      { id: 2, from: 2, to: 3, cost: 4, blocked: false },
      { id: 3, from: 4, to: 5, cost: 3, blocked: false },
      { id: 4, from: 5, to: 6, cost: 4, blocked: false },
      { id: 5, from: 6, to: 7, cost: 6, blocked: false },
      { id: 6, from: 8, to: 9, cost: 5, blocked: false },
      { id: 7, from: 9, to: 10, cost: 4, blocked: false },
      { id: 8, from: 10, to: 11, cost: 5, blocked: false },
      { id: 9, from: 0, to: 4, cost: 5, blocked: false },
      { id: 10, from: 1, to: 5, cost: 4, blocked: false },
      { id: 11, from: 2, to: 6, cost: 5, blocked: false },
      { id: 12, from: 3, to: 7, cost: 6, blocked: false },
      { id: 13, from: 4, to: 8, cost: 4, blocked: false },
      { id: 14, from: 5, to: 9, cost: 3, blocked: false },
      { id: 15, from: 6, to: 10, cost: 4, blocked: false },
      { id: 16, from: 7, to: 11, cost: 5, blocked: false }
    ]
  }
};

// ============================================================================
// HARDWARE-ACCELERATED 3D WEBGL CITY RENDERER (Three.js)
// ============================================================================
class City3DRenderer {
  constructor(app) {
    this.app = app;
    this.container = document.getElementById('threeContainer');
    this.isSupported = typeof THREE !== 'undefined';

    if (!this.isSupported) {
      console.warn("Three.js not loaded. Operating in 2D mode.");
      return;
    }

    this.scene = null;
    this.camera = null;
    this.renderer = null;

    // Camera Modes: 'orbit', 'chase', 'drone', 'cctv'
    this.cameraMode = 'orbit';
    this.isNightMode = true;

    // Orbit Controls State
    this.orbitRadius = 380;
    this.orbitTheta = Math.PI / 4;   // Azimuth angle
    this.orbitPhi = Math.PI / 3.2;   // Elevation angle
    this.orbitTarget = new THREE.Vector3(0, 0, 0);
    this.isOrbitDragging = false;
    this.isOrbitPanning = false;
    this.lastMousePos = { x: 0, y: 0 };
    this.chaseVehicleIndex = 0;

    // 3D Scene Object Registries
    this.cityGroup = new THREE.Group();
    this.roadsGroup = new THREE.Group();
    this.signalsGroup = new THREE.Group();
    this.vehiclesGroup = new THREE.Group();
    this.barricadesGroup = new THREE.Group();
    this.buildingsGroup = new THREE.Group();
    this.corridorsGroup = new THREE.Group();

    this.roadMeshes = new Map();
    this.signalMeshes = new Map();
    this.vehicleMeshes = new Map();
    this.barricadeMeshes = new Map();

    // Raycasting
    this.raycaster = new THREE.Raycaster();
    this.mouse2D = new THREE.Vector2();

    this.initScene();
    this.setupInteractions();
  }

  initScene() {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || (window.innerHeight - 62);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x070b14);
    this.scene.fog = new THREE.FogExp2(0x070b14, 0.0015);

    this.camera = new THREE.PerspectiveCamera(48, width / height, 1, 3000);
    this.updateCameraOrbit();

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;

    this.container.innerHTML = '';
    this.container.appendChild(this.renderer.domElement);

    // Assemble Scene Hierarchy
    this.scene.add(this.cityGroup);
    this.cityGroup.add(this.roadsGroup);
    this.cityGroup.add(this.signalsGroup);
    this.cityGroup.add(this.vehiclesGroup);
    this.cityGroup.add(this.barricadesGroup);
    this.cityGroup.add(this.buildingsGroup);
    this.cityGroup.add(this.corridorsGroup);

    this.setupLighting();
    this.createGround();
  }

  setupLighting() {
    this.ambientLight = new THREE.AmbientLight(0x223355, 0.9);
    this.scene.add(this.ambientLight);

    this.sunLight = new THREE.DirectionalLight(0xddeeff, 1.4);
    this.sunLight.position.set(200, 400, 150);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.width = 2048;
    this.sunLight.shadow.mapSize.height = 2048;
    this.sunLight.shadow.camera.near = 50;
    this.sunLight.shadow.camera.far = 800;
    const d = 350;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0005;
    this.scene.add(this.sunLight);

    // City Center Glow
    this.centerGlow = new THREE.PointLight(0x00f0ff, 1.2, 500);
    this.centerGlow.position.set(0, 40, 0);
    this.scene.add(this.centerGlow);

    this.applyTimeOfDay();
  }

  createGround() {
    // 3D City Foundation Plane
    const groundGeo = new THREE.PlaneGeometry(1600, 1600);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0a101d,
      roughness: 0.9,
      metalness: 0.1
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);

    // Grid Floor Overlay
    const grid = new THREE.GridHelper(1600, 80, 0x1e293b, 0x131d2e);
    grid.position.y = 0.1;
    this.scene.add(grid);
  }

  to3DCoords(x, y) {
    // Maps 2D layout coordinates [100, 600] to 3D world space centered at (0, 0, 0)
    const centerX = 340;
    const centerY = 320;
    const scale = 0.75;
    return {
      x: (x - centerX) * scale,
      y: 0,
      z: (y - centerY) * scale
    };
  }

  buildCityScene(nodes, roads) {
    if (!this.isSupported) return;

    // Clear existing dynamic meshes
    while (this.roadsGroup.children.length > 0) this.roadsGroup.remove(this.roadsGroup.children[0]);
    while (this.signalsGroup.children.length > 0) this.signalsGroup.remove(this.signalsGroup.children[0]);
    while (this.buildingsGroup.children.length > 0) this.buildingsGroup.remove(this.buildingsGroup.children[0]);
    while (this.barricadesGroup.children.length > 0) this.barricadesGroup.remove(this.barricadesGroup.children[0]);

    this.roadMeshes.clear();
    this.signalMeshes.clear();
    this.barricadeMeshes.clear();

    // 1. Build 3D Roads
    roads.forEach(road => {
      this.create3DRoad(road, nodes);
    });

    // 2. Build 3D Intersections & Traffic Signal Gantries
    nodes.forEach(node => {
      this.create3DIntersection(node);
    });

    // 3. Build Procedural City Skyscrapers
    this.createProceduralSkyscrapers(nodes);

    this.updateRoads();
    this.updateSignals(nodes);
  }

  create3DRoad(road, nodes) {
    const u = nodes.find(n => n.id === road.from);
    const v = nodes.find(n => n.id === road.to);
    if (!u || !v) return;

    const p1 = this.to3DCoords(u.x, u.y);
    const p2 = this.to3DCoords(v.x, v.y);

    const dx = p2.x - p1.x;
    const dz = p2.z - p1.z;
    const length = Math.hypot(dx, dz);
    const angle = Math.atan2(dx, dz);

    const roadWidth = 14;
    const roadGeo = new THREE.BoxGeometry(roadWidth, 0.4, length);
    const roadMat = new THREE.MeshStandardMaterial({
      color: 0x141d2c,
      roughness: 0.8,
      metalness: 0.2
    });

    const roadMesh = new THREE.Mesh(roadGeo, roadMat);
    roadMesh.position.set((p1.x + p2.x) / 2, 0.2, (p1.z + p2.z) / 2);
    roadMesh.rotation.y = angle;
    roadMesh.receiveShadow = true;
    roadMesh.userData = { type: 'road', roadId: road.id };

    // Yellow Dashed Lane Divider Ribbon
    const dashGeo = new THREE.PlaneGeometry(0.5, length * 0.9);
    const dashMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    const dashMesh = new THREE.Mesh(dashGeo, dashMat);
    dashMesh.rotation.x = -Math.PI / 2;
    dashMesh.position.y = 0.22;
    roadMesh.add(dashMesh);

    // Curbs on edges
    const curbGeo = new THREE.BoxGeometry(0.8, 0.6, length);
    const curbMat = new THREE.MeshStandardMaterial({ color: 0x334155 });
    const leftCurb = new THREE.Mesh(curbGeo, curbMat);
    leftCurb.position.set(-roadWidth / 2, 0.1, 0);
    const rightCurb = new THREE.Mesh(curbGeo, curbMat);
    rightCurb.position.set(roadWidth / 2, 0.1, 0);
    roadMesh.add(leftCurb);
    roadMesh.add(rightCurb);

    this.roadsGroup.add(roadMesh);
    this.roadMeshes.set(road.id, roadMesh);
  }

  create3DIntersection(node) {
    const p = this.to3DCoords(node.x, node.y);

    // Junction Pad
    const padGeo = new THREE.CylinderGeometry(12, 12, 0.5, 32);
    const padMat = new THREE.MeshStandardMaterial({
      color: 0x182438,
      roughness: 0.7,
      metalness: 0.2
    });
    const pad = new THREE.Mesh(padGeo, padMat);
    pad.position.set(p.x, 0.25, p.z);
    pad.receiveShadow = true;
    pad.userData = { type: 'node', nodeId: node.id };
    this.signalsGroup.add(pad);

    // 4 Directional Cantilever Signal Masts
    const directions = [
      { dir: 'north', angle: 0, rx: 0, rz: -9 },
      { dir: 'south', angle: Math.PI, rx: 0, rz: 9 },
      { dir: 'east',  angle: Math.PI / 2, rx: 9, rz: 0 },
      { dir: 'west',  angle: -Math.PI / 2, rx: -9, rz: 0 }
    ];

    const signalObj = { node, heads: {} };

    directions.forEach(d => {
      const gantryGroup = new THREE.Group();
      gantryGroup.position.set(p.x + d.rx, 0, p.z + d.rz);
      gantryGroup.rotation.y = d.angle;

      // Vertical Steel Mast
      const poleGeo = new THREE.CylinderGeometry(0.3, 0.4, 9, 12);
      const poleMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, roughness: 0.3 });
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.y = 4.5;
      pole.castShadow = true;
      gantryGroup.add(pole);

      // Cantilever Arm
      const armGeo = new THREE.CylinderGeometry(0.2, 0.2, 7, 8);
      const arm = new THREE.Mesh(armGeo, poleMat);
      arm.rotation.z = Math.PI / 2;
      arm.position.set(3.5, 8.5, 0);
      gantryGroup.add(arm);

      // 3-Aspect Signal Box
      const boxGeo = new THREE.BoxGeometry(1.2, 3.2, 0.8);
      const boxMat = new THREE.MeshStandardMaterial({ color: 0x0f172a });
      const box = new THREE.Mesh(boxGeo, boxMat);
      box.position.set(5.5, 7.8, 0);
      gantryGroup.add(box);

      // Red, Yellow, Green Lenses
      const redLens = this.createSignalLens(0xff2222, 0.9);
      const yellowLens = this.createSignalLens(0xffbb00, 0);
      const greenLens = this.createSignalLens(0x00ff66, -0.9);

      box.add(redLens.mesh);
      box.add(yellowLens.mesh);
      box.add(greenLens.mesh);

      // Pre-emption High-Intensity Strobe Beacon on top of pole
      const strobeGeo = new THREE.SphereGeometry(0.4, 12, 12);
      const strobeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const strobe = new THREE.Mesh(strobeGeo, strobeMat);
      strobe.position.set(0, 9.3, 0);
      strobe.visible = false;
      gantryGroup.add(strobe);

      this.signalsGroup.add(gantryGroup);

      signalObj.heads[d.dir] = {
        red: redLens,
        yellow: yellowLens,
        green: greenLens,
        strobe: strobe
      };
    });

    this.signalMeshes.set(node.id, signalObj);
  }

  createSignalLens(colorHex, yOffset) {
    const geo = new THREE.SphereGeometry(0.35, 16, 16);
    const mat = new THREE.MeshStandardMaterial({
      color: 0x222222,
      emissive: colorHex,
      emissiveIntensity: 0.1,
      roughness: 0.3
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(0, yOffset, 0.45);
    return { mesh, mat, colorHex };
  }

  createProceduralSkyscrapers(nodes) {
    const minX = Math.min(...nodes.map(n => n.x));
    const maxX = Math.max(...nodes.map(n => n.x));
    const minY = Math.min(...nodes.map(n => n.y));
    const maxY = Math.max(...nodes.map(n => n.y));

    const pMin = this.to3DCoords(minX, minY);
    const pMax = this.to3DCoords(maxX, maxY);

    // City Boundary Blocks
    const buildingColors = [0x1e293b, 0x172554, 0x1e1b4b, 0x0f172a, 0x262626];

    for (let x = pMin.x - 60; x <= pMax.x + 60; x += 36) {
      for (let z = pMin.z - 60; z <= pMax.z + 60; z += 36) {
        // Skip positions directly on top of road/intersection centers
        const isNearNode = nodes.some(n => {
          const np = this.to3DCoords(n.x, n.y);
          return Math.hypot(np.x - x, np.z - z) < 24;
        });

        if (isNearNode) continue;

        const width = 18 + (Math.sin(x * z) * 6);
        const depth = 18 + (Math.cos(x * z) * 6);
        const height = 30 + Math.abs(Math.sin(x * 12 + z)) * 65;

        const bGeo = new THREE.BoxGeometry(width, height, depth);
        const bMat = new THREE.MeshStandardMaterial({
          color: buildingColors[Math.abs(Math.floor(x + z)) % buildingColors.length],
          roughness: 0.3,
          metalness: 0.7
        });

        const bMesh = new THREE.Mesh(bGeo, bMat);
        bMesh.position.set(x, height / 2, z);
        bMesh.castShadow = true;
        bMesh.receiveShadow = true;

        // Rooftop glowing neon architectural parapet
        const roofTrimGeo = new THREE.BoxGeometry(width + 0.4, 1.2, depth + 0.4);
        const roofTrimMat = new THREE.MeshBasicMaterial({
          color: (x > 0 ? 0x00f0ff : 0xa855f7)
        });
        const roofTrim = new THREE.Mesh(roofTrimGeo, roofTrimMat);
        roofTrim.position.y = height / 2;
        bMesh.add(roofTrim);

        // Blinking red aviation beacon on tallest skyscrapers
        if (height > 65) {
          const beaconGeo = new THREE.SphereGeometry(0.5, 8, 8);
          const beaconMat = new THREE.MeshBasicMaterial({ color: 0xff0033 });
          const beacon = new THREE.Mesh(beaconGeo, beaconMat);
          beacon.position.set(0, height / 2 + 1, 0);
          bMesh.add(beacon);
        }

        this.buildingsGroup.add(bMesh);
      }
    }
  }

  // ==========================================================================
  // 3D PROCEDURAL EMERGENCY VEHICLES (5 Distinct Classes)
  // ==========================================================================
  create3DVehicleMesh(vehicle) {
    const group = new THREE.Group();
    let wheels = [];
    let lightbar = null;
    let light1 = null;
    let light2 = null;
    let light2Color = 0xffffff;

    if (vehicle.type === 1) {
      // 🚑 1. AMBULANCE (High-Top Emergency Medical Van)
      const bodyMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3 });
      const stripeMat = new THREE.MeshStandardMaterial({ color: 0xef4444 });
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.1 });

      const cabGeo = new THREE.BoxGeometry(4.5, 3.2, 5.5);
      const cab = new THREE.Mesh(cabGeo, bodyMat);
      cab.position.set(0, 2.2, 1.8);
      cab.castShadow = true;
      group.add(cab);

      const boxGeo = new THREE.BoxGeometry(4.8, 4.0, 7.5);
      const box = new THREE.Mesh(boxGeo, bodyMat);
      box.position.set(0, 2.8, -2.5);
      box.castShadow = true;
      group.add(box);

      // Red Chevrons
      const redStripeGeo = new THREE.BoxGeometry(4.9, 0.8, 7.6);
      const stripe = new THREE.Mesh(redStripeGeo, stripeMat);
      stripe.position.set(0, 2.4, -2.5);
      group.add(stripe);

      // Red Cross on Box Roof
      const crossVGeo = new THREE.BoxGeometry(0.8, 0.1, 2.4);
      const crossHGeo = new THREE.BoxGeometry(2.4, 0.1, 0.8);
      const crossV = new THREE.Mesh(crossVGeo, stripeMat);
      const crossH = new THREE.Mesh(crossHGeo, stripeMat);
      crossV.position.set(0, 4.85, -2.5);
      crossH.position.set(0, 4.85, -2.5);
      group.add(crossV);
      group.add(crossH);

      // Windshield
      const winGeo = new THREE.BoxGeometry(4.3, 1.4, 0.8);
      const win = new THREE.Mesh(winGeo, glassMat);
      win.position.set(0, 2.8, 4.2);
      group.add(win);

      // 4 Wheels
      const wheelGeo = new THREE.CylinderGeometry(0.9, 0.9, 0.6, 16);
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 });
      [[-2.3, 0.9, 2.8], [2.3, 0.9, 2.8], [-2.3, 0.9, -2.8], [2.3, 0.9, -2.8]].forEach(wp => {
        const wMesh = new THREE.Mesh(wheelGeo, wheelMat);
        wMesh.rotation.z = Math.PI / 2;
        wMesh.position.set(wp[0], wp[1], wp[2]);
        group.add(wMesh);
        wheels.push(wMesh);
      });

      // Rooftop Lightbars & Lights (Red & White)
      const lightbarGeo = new THREE.BoxGeometry(3.2, 0.5, 0.9);
      const lightbarMat = new THREE.MeshBasicMaterial({ color: 0xff0033 });
      lightbar = new THREE.Mesh(lightbarGeo, lightbarMat);
      lightbar.position.set(0, 5.2, 0.5);
      group.add(lightbar);

      light1 = new THREE.PointLight(0xff0033, 2.8, 35);
      light1.position.set(-1.5, 5.2, 0);
      group.add(light1);

      light2Color = 0xffffff;
      light2 = new THREE.PointLight(light2Color, 2.8, 35);
      light2.position.set(1.5, 5.2, 0);
      group.add(light2);

    } else if (vehicle.type === 2) {
      // 🚒 2. FIRE PUMPER (Heavy Rescue Engine)
      const redMat = new THREE.MeshStandardMaterial({ color: 0xd92d20, roughness: 0.4 });
      const chromeMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9, roughness: 0.1 });
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.1 });

      const chassisGeo = new THREE.BoxGeometry(5.2, 4.2, 12);
      const chassis = new THREE.Mesh(chassisGeo, redMat);
      chassis.position.set(0, 2.6, 0);
      chassis.castShadow = true;
      group.add(chassis);

      // Cab Windshield
      const winGeo = new THREE.BoxGeometry(4.8, 1.4, 0.6);
      const win = new THREE.Mesh(winGeo, glassMat);
      win.position.set(0, 3.4, 5.8);
      group.add(win);

      // Chrome Water Monitor / Roof Deck Gun
      const monitorBaseGeo = new THREE.CylinderGeometry(0.5, 0.6, 0.8, 12);
      const monitorBase = new THREE.Mesh(monitorBaseGeo, chromeMat);
      monitorBase.position.set(0, 5.1, 1.8);
      group.add(monitorBase);

      const nozzleGeo = new THREE.CylinderGeometry(0.2, 0.35, 1.6, 8);
      const nozzle = new THREE.Mesh(nozzleGeo, chromeMat);
      nozzle.rotation.x = Math.PI / 3;
      nozzle.position.set(0, 5.7, 2.4);
      group.add(nozzle);

      // Chrome Side Pump Panels
      const pumpGeo = new THREE.BoxGeometry(0.2, 1.8, 3.2);
      const pumpL = new THREE.Mesh(pumpGeo, chromeMat);
      pumpL.position.set(-2.65, 2.2, -0.5);
      group.add(pumpL);

      const pumpR = new THREE.Mesh(pumpGeo, chromeMat);
      pumpR.position.set(2.65, 2.2, -0.5);
      group.add(pumpR);

      // Chrome Ladder on Roof
      const ladderGeo = new THREE.BoxGeometry(1.8, 0.3, 8.5);
      const ladder = new THREE.Mesh(ladderGeo, chromeMat);
      ladder.position.set(-1.2, 5.0, -1.5);
      group.add(ladder);

      // Front Chrome Grille & Bumper
      const grilleGeo = new THREE.BoxGeometry(4.8, 1.8, 0.4);
      const grille = new THREE.Mesh(grilleGeo, chromeMat);
      grille.position.set(0, 2.0, 6.1);
      group.add(grille);

      // 6 Wheels (Heavy 3-Axle Setup)
      const wheelGeo = new THREE.CylinderGeometry(1.0, 1.0, 0.7, 16);
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 });
      [
        [-2.5, 1.0, 4.0], [2.5, 1.0, 4.0],
        [-2.5, 1.0, -1.8], [2.5, 1.0, -1.8],
        [-2.5, 1.0, -4.4], [2.5, 1.0, -4.4]
      ].forEach(wp => {
        const wMesh = new THREE.Mesh(wheelGeo, wheelMat);
        wMesh.rotation.z = Math.PI / 2;
        wMesh.position.set(wp[0], wp[1], wp[2]);
        group.add(wMesh);
        wheels.push(wMesh);
      });

      // Red & Amber Rotating Emergency Strobes
      const lightbarGeo = new THREE.BoxGeometry(3.6, 0.5, 0.9);
      const lightbarMat = new THREE.MeshBasicMaterial({ color: 0xff0033 });
      lightbar = new THREE.Mesh(lightbarGeo, lightbarMat);
      lightbar.position.set(0, 5.2, 4.2);
      group.add(lightbar);

      light1 = new THREE.PointLight(0xff0033, 3.2, 40);
      light1.position.set(-1.8, 5.4, 4.2);
      group.add(light1);

      light2Color = 0xff7700;
      light2 = new THREE.PointLight(light2Color, 3.2, 40);
      light2.position.set(1.8, 5.4, 4.2);
      group.add(light2);

    } else if (vehicle.type === 4) {
      // 🪜 4. AERIAL LADDER TRUCK (Heavy 3-Axle Turntable Ladder)
      const redMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.4 });
      const chromeMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, metalness: 0.92, roughness: 0.1 });
      const darkMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.7 });
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.1 });

      // Extended chassis (length 15.5)
      const chassisGeo = new THREE.BoxGeometry(5.2, 3.8, 15.5);
      const chassis = new THREE.Mesh(chassisGeo, redMat);
      chassis.position.set(0, 2.4, 0);
      chassis.castShadow = true;
      group.add(chassis);

      // Elevated Cab
      const cabGeo = new THREE.BoxGeometry(5.0, 3.2, 4.5);
      const cab = new THREE.Mesh(cabGeo, redMat);
      cab.position.set(0, 3.4, 5.2);
      group.add(cab);

      // Cab Windshield
      const winGeo = new THREE.BoxGeometry(4.7, 1.4, 0.5);
      const win = new THREE.Mesh(winGeo, glassMat);
      win.position.set(0, 3.8, 7.3);
      group.add(win);

      // Rear Rotating Turntable Pedestal
      const turntableGeo = new THREE.CylinderGeometry(1.6, 1.8, 1.0, 16);
      const turntable = new THREE.Mesh(turntableGeo, darkMat);
      turntable.position.set(0, 4.5, -4.5);
      group.add(turntable);

      // Articulated Telescopic Silver Aerial Ladder
      const mainLadderGeo = new THREE.BoxGeometry(2.2, 0.6, 13.5);
      const mainLadder = new THREE.Mesh(mainLadderGeo, chromeMat);
      mainLadder.position.set(0, 5.3, 0.8);
      mainLadder.castShadow = true;
      group.add(mainLadder);

      // Telescopic Extension Rails
      const extLadderGeo = new THREE.BoxGeometry(1.6, 0.4, 11.5);
      const extLadder = new THREE.Mesh(extLadderGeo, chromeMat);
      extLadder.position.set(0, 5.7, 1.2);
      group.add(extLadder);

      // Outriggers on flanks
      const outriggerMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b });
      const outGeo = new THREE.BoxGeometry(5.8, 0.8, 1.2);
      const outF = new THREE.Mesh(outGeo, outriggerMat);
      outF.position.set(0, 1.6, -1.0);
      group.add(outF);

      // Front Chrome Grille
      const grilleGeo = new THREE.BoxGeometry(4.8, 1.8, 0.4);
      const grille = new THREE.Mesh(grilleGeo, chromeMat);
      grille.position.set(0, 2.0, 7.8);
      group.add(grille);

      // 6 Wheels (Dual rear bogie)
      const wheelGeo = new THREE.CylinderGeometry(1.0, 1.0, 0.7, 16);
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 });
      [
        [-2.5, 1.0, 5.2], [2.5, 1.0, 5.2],
        [-2.5, 1.0, -3.2], [2.5, 1.0, -3.2],
        [-2.5, 1.0, -5.8], [2.5, 1.0, -5.8]
      ].forEach(wp => {
        const wMesh = new THREE.Mesh(wheelGeo, wheelMat);
        wMesh.rotation.z = Math.PI / 2;
        wMesh.position.set(wp[0], wp[1], wp[2]);
        group.add(wMesh);
        wheels.push(wMesh);
      });

      // Dual Red / Amber Strobes
      const lightbarGeo = new THREE.BoxGeometry(3.8, 0.5, 0.9);
      const lightbarMat = new THREE.MeshBasicMaterial({ color: 0xff0033 });
      lightbar = new THREE.Mesh(lightbarGeo, lightbarMat);
      lightbar.position.set(0, 5.5, 5.5);
      group.add(lightbar);

      light1 = new THREE.PointLight(0xff0033, 3.4, 45);
      light1.position.set(-1.8, 5.6, 5.5);
      group.add(light1);

      light2Color = 0xffaa00;
      light2 = new THREE.PointLight(light2Color, 3.4, 45);
      light2.position.set(1.8, 5.6, 5.5);
      group.add(light2);

    } else if (vehicle.type === 5) {
      // 🚔 5. SWAT BEARCAT (Tactical Armored Rescue Vehicle)
      const armorMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.75, metalness: 0.4 });
      const steelMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.5, metalness: 0.8 });
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.2 });

      // Main Armored Faceted Hull
      const hullGeo = new THREE.BoxGeometry(4.8, 3.2, 9.5);
      const hull = new THREE.Mesh(hullGeo, armorMat);
      hull.position.set(0, 2.3, 0);
      hull.castShadow = true;
      group.add(hull);

      // Angled Armored Hood
      const hoodGeo = new THREE.BoxGeometry(4.6, 1.8, 3.2);
      const hood = new THREE.Mesh(hoodGeo, armorMat);
      hood.position.set(0, 1.8, 3.6);
      group.add(hood);

      // Narrow Bulletproof Slit Viewports
      const slitGeo = new THREE.BoxGeometry(4.2, 0.6, 0.4);
      const slit = new THREE.Mesh(slitGeo, glassMat);
      slit.position.set(0, 3.0, 3.6);
      group.add(slit);

      // Roof Observation Gunner Turret Hatch
      const turretGeo = new THREE.CylinderGeometry(1.2, 1.3, 0.8, 12);
      const turret = new THREE.Mesh(turretGeo, steelMat);
      turret.position.set(0, 4.2, 0.5);
      group.add(turret);

      // Heavy Reinforced Battering Ram Bumper
      const ramGeo = new THREE.BoxGeometry(5.0, 1.4, 0.8);
      const ram = new THREE.Mesh(ramGeo, steelMat);
      ram.position.set(0, 1.2, 5.4);
      group.add(ram);

      // 4 Heavy All-Terrain Combat Wheels
      const wheelGeo = new THREE.CylinderGeometry(1.1, 1.1, 0.8, 16);
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.95 });
      [
        [-2.5, 1.1, 3.0], [2.5, 1.1, 3.0],
        [-2.5, 1.1, -3.0], [2.5, 1.1, -3.0]
      ].forEach(wp => {
        const wMesh = new THREE.Mesh(wheelGeo, wheelMat);
        wMesh.rotation.z = Math.PI / 2;
        wMesh.position.set(wp[0], wp[1], wp[2]);
        group.add(wMesh);
        wheels.push(wMesh);
      });

      // Stealth Tactical Blue & Cyan Perimeter Strobes
      const lightbarGeo = new THREE.BoxGeometry(3.2, 0.4, 0.7);
      const lightbarMat = new THREE.MeshBasicMaterial({ color: 0x0088ff });
      lightbar = new THREE.Mesh(lightbarGeo, lightbarMat);
      lightbar.position.set(0, 4.1, 2.2);
      group.add(lightbar);

      light1 = new THREE.PointLight(0x0088ff, 3.0, 35);
      light1.position.set(-1.5, 4.2, 2.2);
      group.add(light1);

      light2Color = 0x38bdf8;
      light2 = new THREE.PointLight(light2Color, 2.8, 35);
      light2.position.set(1.5, 4.2, 2.2);
      group.add(light2);

    } else {
      // 🚓 3. POLICE CRUISER (Tactical Interceptor)
      const blackMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2 });
      const whiteMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.2 });
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.1 });

      const bodyGeo = new THREE.BoxGeometry(4.2, 1.8, 8.5);
      const body = new THREE.Mesh(bodyGeo, blackMat);
      body.position.set(0, 1.4, 0);
      body.castShadow = true;
      group.add(body);

      // White Doors
      const doorGeo = new THREE.BoxGeometry(4.25, 1.2, 3.5);
      const doors = new THREE.Mesh(doorGeo, whiteMat);
      doors.position.set(0, 1.4, 0);
      group.add(doors);

      // Cabin Glass Canopy
      const cabinGeo = new THREE.BoxGeometry(3.6, 1.3, 4.2);
      const cabin = new THREE.Mesh(cabinGeo, glassMat);
      cabin.position.set(0, 2.7, -0.5);
      group.add(cabin);

      // Front Push Bumper
      const pushMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8 });
      const pushGeo = new THREE.BoxGeometry(4.4, 1.2, 0.5);
      const push = new THREE.Mesh(pushGeo, pushMat);
      push.position.set(0, 1.2, 4.4);
      group.add(push);

      // 4 Pursuit Wheels
      const wheelGeo = new THREE.CylinderGeometry(0.9, 0.9, 0.6, 16);
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 });
      [
        [-2.3, 0.9, 2.8], [2.3, 0.9, 2.8],
        [-2.3, 0.9, -2.8], [2.3, 0.9, -2.8]
      ].forEach(wp => {
        const wMesh = new THREE.Mesh(wheelGeo, wheelMat);
        wMesh.rotation.z = Math.PI / 2;
        wMesh.position.set(wp[0], wp[1], wp[2]);
        group.add(wMesh);
        wheels.push(wMesh);
      });

      // Dual Red & Blue Pursuit Strobes
      const lightbarGeo = new THREE.BoxGeometry(3.2, 0.5, 0.9);
      const lightbarMat = new THREE.MeshBasicMaterial({ color: 0xff0033 });
      lightbar = new THREE.Mesh(lightbarGeo, lightbarMat);
      lightbar.position.set(0, 3.6, 0.5);
      group.add(lightbar);

      light1 = new THREE.PointLight(0xff0033, 2.8, 35);
      light1.position.set(-1.5, 3.8, 0.5);
      group.add(light1);

      light2Color = 0x0099ff;
      light2 = new THREE.PointLight(light2Color, 2.8, 35);
      light2.position.set(1.5, 3.8, 0.5);
      group.add(light2);
    }

    group.userData = {
      vehicleId: vehicle.id,
      wheels: wheels,
      lightbar: lightbar,
      light1: light1,
      light2: light2,
      light2Color: light2Color
    };

    return group;
  }

  // ==========================================================================
  // REAL-TIME UPDATES FOR 3D ROADS, BARRICADES & CORRIDORS
  // ==========================================================================
  updateRoads() {
    this.app.roads.forEach(road => {
      const mesh = this.roadMeshes.get(road.id);
      if (!mesh) return;

      if (road.blocked) {
        mesh.material.color.setHex(0x7f1d1d);
        // Add 3D A-Frame Construction Barricades if not present
        if (!this.barricadeMeshes.has(road.id)) {
          this.create3DBarricade(road);
        }
      } else if (road.cost >= 30) {
        mesh.material.color.setHex(0xb45309); // Amber Congested
        this.remove3DBarricade(road.id);
      } else {
        mesh.material.color.setHex(0x141d2c); // Normal Asphalt
        this.remove3DBarricade(road.id);
      }
    });
  }

  create3DBarricade(road) {
    const u = this.app.nodes.find(n => n.id === road.from);
    const v = this.app.nodes.find(n => n.id === road.to);
    if (!u || !v) return;

    const p1 = this.to3DCoords(u.x, u.y);
    const p2 = this.to3DCoords(v.x, v.y);
    const midX = (p1.x + p2.x) / 2;
    const midZ = (p1.z + p2.z) / 2;
    const angle = Math.atan2(p2.x - p1.x, p2.z - p1.z);

    const group = new THREE.Group();
    group.position.set(midX, 0, midZ);
    group.rotation.y = angle + Math.PI / 2;

    // A-Frame Board with Warning Stripes
    const boardGeo = new THREE.BoxGeometry(11, 2.2, 0.4);
    const boardMat = new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.3 });
    const board = new THREE.Mesh(boardGeo, boardMat);
    board.position.y = 2.5;
    board.castShadow = true;
    group.add(board);

    // Hazard Stripes
    const stripeGeo = new THREE.BoxGeometry(11.1, 0.8, 0.45);
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const stripe = new THREE.Mesh(stripeGeo, stripeMat);
    stripe.position.y = 2.5;
    group.add(stripe);

    // Dual Flashing Hazard Strobes
    const strobeGeo = new THREE.SphereGeometry(0.4, 8, 8);
    const strobeMat = new THREE.MeshBasicMaterial({ color: 0xffaa00 });
    const st1 = new THREE.Mesh(strobeGeo, strobeMat);
    st1.position.set(-4.5, 4.0, 0);
    const st2 = new THREE.Mesh(strobeGeo, strobeMat);
    st2.position.set(4.5, 4.0, 0);
    group.add(st1);
    group.add(st2);

    this.barricadesGroup.add(group);
    this.barricadeMeshes.set(road.id, group);
  }

  remove3DBarricade(roadId) {
    const mesh = this.barricadeMeshes.get(roadId);
    if (mesh) {
      this.barricadesGroup.remove(mesh);
      this.barricadeMeshes.delete(roadId);
    }
  }

  updateSignals(nodes) {
    nodes.forEach(node => {
      const sigData = this.signalMeshes.get(node.id);
      if (!sigData) return;

      const hasOverride = !!node.signals.override;

      ['north', 'south', 'east', 'west'].forEach(dir => {
        const head = sigData.heads[dir];
        const state = node.signals[dir].state;

        head.red.mat.emissiveIntensity = (state === 'red') ? 1.8 : 0.05;
        head.yellow.mat.emissiveIntensity = (state === 'yellow') ? 1.8 : 0.05;
        head.green.mat.emissiveIntensity = (state === 'green') ? 2.2 : 0.05;

        // Pre-emption Mast Strobe Rapid Flash
        if (hasOverride) {
          head.strobe.visible = (performance.now() % 250) < 125;
        } else {
          head.strobe.visible = false;
        }
      });
    });
  }

  update3DVehicles(deltaTime) {
    if (!this.isSupported) return;

    // Remove arrived or deleted vehicles
    const activeIds = new Set(this.app.activeVehicles.map(v => v.id));
    for (const [id, mesh] of this.vehicleMeshes.entries()) {
      if (!activeIds.has(id)) {
        this.vehiclesGroup.remove(mesh);
        this.vehicleMeshes.delete(id);
      }
    }

    // Update or spawn active vehicles
    this.app.activeVehicles.forEach(vehicle => {
      if (vehicle.state === 'arrived') {
        const m = this.vehicleMeshes.get(vehicle.id);
        if (m) {
          this.vehiclesGroup.remove(m);
          this.vehicleMeshes.delete(vehicle.id);
        }
        return;
      }

      let vMesh = this.vehicleMeshes.get(vehicle.id);
      if (!vMesh) {
        vMesh = this.create3DVehicleMesh(vehicle);
        this.vehiclesGroup.add(vMesh);
        this.vehicleMeshes.set(vehicle.id, vMesh);
      }

      const uNode = this.app.nodes.find(n => n.id === vehicle.currentNode);
      const vNode = this.app.nodes.find(n => n.id === vehicle.targetNode);
      if (!uNode || !vNode) return;

      const p1 = this.to3DCoords(uNode.x, uNode.y);
      const p2 = this.to3DCoords(vNode.x, vNode.y);

      // Lerp position
      const p = Math.min(Math.max(vehicle.progress, 0), 1);
      const posX = p1.x + (p2.x - p1.x) * p;
      const posZ = p1.z + (p2.z - p1.z) * p;

      vMesh.position.set(posX, 0.4, posZ);

      // Heading angle
      const heading = Math.atan2(p2.x - p1.x, p2.z - p1.z);
      vMesh.rotation.y = heading;

      // Wheel Spin
      const speed = vehicle.speed * this.app.simSpeed;
      vMesh.userData.wheels.forEach(w => {
        w.rotation.x += speed * 25;
      });

      // Alternating Emergency Lightbar Strobe
      const blink = (performance.now() % 280) < 140;
      vMesh.userData.light1.intensity = blink ? 3.5 : 0.2;
      vMesh.userData.light2.intensity = blink ? 0.2 : 3.5;
      vMesh.userData.lightbar.material.color.setHex(blink ? 0xff0033 : vMesh.userData.light2Color);
    });

    // Update 3D Holographic Pre-emption Corridor Ribbon
    this.update3DCorridors();

    // Update Camera Target if Chase Cam
    if (this.cameraMode === 'chase') {
      const activeVehicles = this.app.activeVehicles.filter(v => v.state !== 'arrived');
      if (activeVehicles.length > 0) {
        if (this.chaseVehicleIndex >= activeVehicles.length) {
          this.chaseVehicleIndex = 0;
        }
        const activeV = activeVehicles[this.chaseVehicleIndex];
        if (activeV) {
          const vMesh = this.vehicleMeshes.get(activeV.id);
          if (vMesh) {
            const chaseOffset = new THREE.Vector3(0, 16, -32).applyAxisAngle(new THREE.Vector3(0, 1, 0), vMesh.rotation.y);
            const targetCamPos = vMesh.position.clone().add(chaseOffset);
            this.camera.position.lerp(targetCamPos, 0.08);
            this.camera.lookAt(vMesh.position.clone().add(new THREE.Vector3(0, 3, 0)));
          }
        }
      } else {
        this.cameraMode = 'orbit';
        const camSel = document.getElementById('camera3DSelect');
        if (camSel) camSel.value = 'orbit';
      }
    }
  }

  update3DCorridors() {
    while (this.corridorsGroup.children.length > 0) {
      this.corridorsGroup.remove(this.corridorsGroup.children[0]);
    }

    this.app.activeVehicles.forEach(v => {
      if (v.state !== 'en_route' || v.route.length < 2) return;

      const points = [];
      v.route.forEach(nodeId => {
        const node = this.app.nodes.find(n => n.id === nodeId);
        if (node) {
          const p = this.to3DCoords(node.x, node.y);
          points.push(new THREE.Vector3(p.x, 0.45, p.z));
        }
      });

      if (points.length >= 2) {
        let ribbonColor = 0x10b981; // Ambulance (Green)
        if (v.type === 2) ribbonColor = 0xef4444; // Fire Pumper (Red)
        else if (v.type === 3) ribbonColor = 0x00f0ff; // Police Cruiser (Cyan)
        else if (v.type === 4) ribbonColor = 0xf59e0b; // Aerial Ladder (Amber Gold)
        else if (v.type === 5) ribbonColor = 0xa855f7; // SWAT BearCat (Purple)

        const curve = new THREE.CatmullRomCurve3(points);
        const tubeGeo = new THREE.TubeGeometry(curve, 64, 0.9, 8, false);
        const tubeMat = new THREE.MeshBasicMaterial({
          color: ribbonColor,
          wireframe: false,
          transparent: true,
          opacity: 0.82
        });
        const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
        this.corridorsGroup.add(tubeMesh);
      }
    });
  }

  // ==========================================================================
  // CAMERA CONTROLS & DAY / NIGHT MODES
  // ==========================================================================
  updateCameraOrbit() {
    if (this.cameraMode !== 'orbit' && this.cameraMode !== 'drone') return;

    this.camera.position.x = this.orbitTarget.x + this.orbitRadius * Math.sin(this.orbitPhi) * Math.sin(this.orbitTheta);
    this.camera.position.y = this.orbitTarget.y + this.orbitRadius * Math.cos(this.orbitPhi);
    this.camera.position.z = this.orbitTarget.z + this.orbitRadius * Math.sin(this.orbitPhi) * Math.cos(this.orbitTheta);
    this.camera.lookAt(this.orbitTarget);
  }

  setCameraMode(mode) {
    this.cameraMode = mode;

    if (mode === 'drone') {
      this.orbitRadius = 450;
      this.orbitPhi = 0.4;
      this.orbitTheta = 0.1;
      this.orbitTarget.set(0, 0, 0);
      this.updateCameraOrbit();
    } else if (mode === 'cctv') {
      // Perch on selected intersection
      const nodeId = this.app.selectedNodeId !== null ? this.app.selectedNodeId : 0;
      const node = this.app.nodes.find(n => n.id === nodeId);
      if (node) {
        const p = this.to3DCoords(node.x, node.y);
        this.camera.position.set(p.x - 14, 20, p.z - 14);
        this.camera.lookAt(p.x, 0, p.z);
      }
    } else if (mode === 'orbit') {
      this.orbitRadius = 380;
      this.orbitPhi = Math.PI / 3.2;
      this.orbitTheta = Math.PI / 4;
      this.orbitTarget.set(0, 0, 0);
      this.updateCameraOrbit();
    }
  }

  cycleVehicleCam(direction) {
    const activeVehicles = this.app.activeVehicles.filter(v => v.state !== 'arrived');
    if (activeVehicles.length === 0) {
      this.app.log("No active emergency units to track with chase camera.", "system");
      return;
    }
    this.chaseVehicleIndex = (this.chaseVehicleIndex + direction + activeVehicles.length) % activeVehicles.length;
    this.setCameraMode('chase');
    const camSelect = document.getElementById('camera3DSelect');
    if (camSelect) camSelect.value = 'chase';
    const tracked = activeVehicles[this.chaseVehicleIndex];
    if (tracked) {
      this.app.log(`🎥 [3D CHASE CAM] Tracking unit: ${tracked.callsign} (${tracked.typeName}, Priority: ${tracked.priorityScore}) [${this.chaseVehicleIndex + 1}/${activeVehicles.length}]`, "system");
    }
  }

  applyTimeOfDay() {
    if (this.isNightMode) {
      this.scene.background.setHex(0x070b14);
      this.scene.fog.color.setHex(0x070b14);
      this.ambientLight.color.setHex(0x1a2640);
      this.ambientLight.intensity = 0.8;
      this.sunLight.intensity = 0.4;
      this.centerGlow.intensity = 1.5;
    } else {
      this.scene.background.setHex(0x7dd3fc); // Blue Sky
      this.scene.fog.color.setHex(0xbae6fd);
      this.ambientLight.color.setHex(0xffffff);
      this.ambientLight.intensity = 1.4;
      this.sunLight.intensity = 2.0;
      this.centerGlow.intensity = 0.2;
    }
  }

  setupInteractions() {
    const el = this.container;

    el.addEventListener('mousedown', (e) => {
      if (e.button === 0) this.isOrbitDragging = true;
      if (e.button === 2) this.isOrbitPanning = true;
      this.lastMousePos = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mousemove', (e) => {
      const dx = e.clientX - this.lastMousePos.x;
      const dy = e.clientY - this.lastMousePos.y;
      this.lastMousePos = { x: e.clientX, y: e.clientY };

      if (this.isOrbitDragging && this.cameraMode === 'orbit') {
        this.orbitTheta -= dx * 0.006;
        this.orbitPhi = Math.min(Math.max(this.orbitPhi - dy * 0.006, 0.15), Math.PI / 2.05);
        this.updateCameraOrbit();
      }

      if (this.isOrbitPanning && this.cameraMode === 'orbit') {
        const panSpeed = 0.4;
        const forward = new THREE.Vector3();
        this.camera.getWorldDirection(forward);
        const right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();

        this.orbitTarget.addScaledVector(right, -dx * panSpeed);
        this.orbitTarget.addScaledVector(new THREE.Vector3(forward.x, 0, forward.z).normalize(), dy * panSpeed);
        this.updateCameraOrbit();
      }
    });

    window.addEventListener('mouseup', () => {
      this.isOrbitDragging = false;
      this.isOrbitPanning = false;
    });

    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      if (this.cameraMode === 'orbit' || this.cameraMode === 'drone') {
        this.orbitRadius = Math.min(Math.max(this.orbitRadius + e.deltaY * 0.35, 80), 900);
        this.updateCameraOrbit();
      }
    });

    el.addEventListener('contextmenu', (e) => e.preventDefault());

    // 3D Raycasting Object Click
    el.addEventListener('click', (e) => {
      const rect = el.getBoundingClientRect();
      this.mouse2D.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse2D.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      this.raycaster.setFromCamera(this.mouse2D, this.camera);
      const hits = this.raycaster.intersectObjects([
        ...this.roadsGroup.children,
        ...this.signalsGroup.children
      ], true);

      if (hits.length > 0) {
        let curr = hits[0].object;
        while (curr && !curr.userData.type && curr.parent) curr = curr.parent;

        if (curr && curr.userData) {
          if (curr.userData.type === 'road') {
            this.app.openRoadModal(curr.userData.roadId);
          } else if (curr.userData.type === 'node') {
            this.app.selectNode(curr.userData.nodeId);
            if (this.cameraMode === 'cctv') this.setCameraMode('cctv');
          }
        }
      }
    });
  }

  resize() {
    if (!this.renderer || !this.camera) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  render(deltaTime) {
    if (!this.isSupported || !this.renderer) return;

    this.update3DVehicles(deltaTime);
    this.updateSignals(this.app.nodes);

    this.renderer.render(this.scene, this.camera);
  }
}

// ============================================================================
// MAIN APPLICATION ORCHESTRATOR
// ============================================================================
class UEPEApp {
  constructor() {
    this.sound = new SoundEffects();

    // Map & Network State
    this.nodes = [];
    this.roads = [];
    this.currentPresetKey = 'downtown';

    // Emergency Fleet State
    this.activeVehicles = [];
    this.vehicleCounter = 1;

    // Simulation Engine State
    this.isPlaying = false;
    this.simSpeed = 1.0;
    this.lastFrameTime = performance.now();
    this.showSignals = true;
    this.showCosts = true;
    this.showBuildings = true;

    // View Mode: '3d' or '2d'
    this.viewMode = '3d';

    // 2D Canvas State
    this.canvas2D = document.getElementById('cityMapCanvas');
    this.ctx2D = this.canvas2D.getContext('2d');
    this.panX = 40;
    this.panY = 30;
    this.zoom = 1.0;
    this.isDragging2D = false;
    this.dragStartX2D = 0;
    this.dragStartY2D = 0;

    // Selected Elements
    this.selectedNodeId = null;
    this.selectedRoadId = null;

    // Pre-emption limit (from C++ code constant)
    this.PREEMPTION_LIMIT = 50;

    // Initialize 3D WebGL Renderer
    this.city3D = new City3DRenderer(this);

    // Initialize Components
    this.loadPreset(this.currentPresetKey);
    this.setupEventListeners();
    this.setupMultiDispatch();
    this.setupSignalClock();
    this.resizeCanvas();
    this.runLoop();

    this.log("Urban Emergency Pre-Emption Engine (UEPE) 3D initialized. Hardware WebGL active.", "system");
  }

  // ==========================================================================
  // MAP SCENARIO MANAGEMENT
  // ==========================================================================
  loadPreset(presetKey) {
    const preset = MAP_PRESETS[presetKey];
    if (!preset) return;

    this.currentPresetKey = presetKey;
    this.nodes = JSON.parse(JSON.stringify(preset.nodes)).map(n => ({
      ...n,
      signals: {
        north: { state: 'red', timer: 15 },
        south: { state: 'red', timer: 15 },
        east: { state: 'green', timer: 20 },
        west: { state: 'green', timer: 20 },
        override: null,
        cycleTimer: 0
      }
    }));

    this.roads = JSON.parse(JSON.stringify(preset.roads));
    this.activeVehicles = [];

    this.populateSelectOptions();
    this.renderRoadInventoryList();
    this.updateStatsDisplay();

    // Rebuild 3D City
    if (this.city3D && this.city3D.isSupported) {
      this.city3D.buildCityScene(this.nodes, this.roads);
    }

    if (this.nodes.length > 0) {
      this.selectNode(this.nodes[0].id);
    }
  }

  populateSelectOptions() {
    const startSelect = document.getElementById('startNodeSelect');
    const destSelect = document.getElementById('destNodeSelect');
    const tfDestSelect = document.getElementById('tfDestNodeSelect');
    if (!startSelect || !destSelect) return;

    startSelect.innerHTML = '';
    destSelect.innerHTML = '';
    if (tfDestSelect) tfDestSelect.innerHTML = '';

    this.nodes.forEach(n => {
      const opt1 = document.createElement('option');
      opt1.value = n.id;
      opt1.textContent = `[${n.id}] ${n.name}`;
      startSelect.appendChild(opt1);

      const opt2 = document.createElement('option');
      opt2.value = n.id;
      opt2.textContent = `[${n.id}] ${n.name}`;
      destSelect.appendChild(opt2);

      if (tfDestSelect) {
        const opt3 = document.createElement('option');
        opt3.value = n.id;
        opt3.textContent = `[${n.id}] ${n.name}`;
        tfDestSelect.appendChild(opt3);
      }
    });

    if (this.nodes.length >= 2) {
      startSelect.selectedIndex = 0;
      destSelect.selectedIndex = this.nodes.length - 1;
      if (tfDestSelect) {
        tfDestSelect.selectedIndex = Math.min(4, this.nodes.length - 1);
      }
    }

    this.updateTaskForceTotalDisplay();
    this.refreshMultiDispatchNodeOptions();
  }

  // ==========================================================================
  // VEHICLE PRIORITY SCORE & PRE-EMPTION ELIGIBILITY (5 Classes)
  // ==========================================================================
  calculatePriorityScore(type, urgency) {
    let bonus = 10;
    if (type === 1) bonus = 30;      // 🚑 Ambulance
    else if (type === 4) bonus = 25; // 🪜 Aerial Ladder
    else if (type === 2) bonus = 20; // 🚒 Fire Pumper
    else if (type === 5) bonus = 15; // 🚔 SWAT BearCat
    else if (type === 3) bonus = 10; // 🚓 Police Cruiser
    return urgency * 10 + bonus;
  }

  getVehicleTypeName(type) {
    switch (type) {
      case 1: return "Ambulance";
      case 2: return "Fire Pumper";
      case 3: return "Police Cruiser";
      case 4: return "Aerial Ladder";
      case 5: return "SWAT BearCat";
      default: return "Emergency Vehicle";
    }
  }

  dispatchVehicle() {
    const type = parseInt(document.querySelector('input[name="vehicleType"]:checked')?.value || '1', 10);
    const urgency = parseInt(document.getElementById('urgencySlider').value || '4', 10);
    const startId = parseInt(document.getElementById('startNodeSelect').value, 10);
    const destId = parseInt(document.getElementById('destNodeSelect').value, 10);
    const customName = document.getElementById('vehicleCustomName').value.trim();
    const quantity = Math.min(Math.max(parseInt(document.getElementById('vehicleQuantityInput')?.value || '1', 10), 1), 10);

    if (startId === destId) {
      alert("Origin and destination cannot be the same intersection!");
      return;
    }

    const priorityScore = this.calculatePriorityScore(type, urgency);
    const routeData = DijkstraRouter.findRoute(this.nodes, this.roads, startId, destId);

    if (routeData.route.length < 2) {
      alert(`No viable road currently connects Intersection ${startId} to ${destId}! Reopen a road first.`);
      this.log(`[DISPATCH BLOCKED] Path disconnected between ${startId} and ${destId}.`, "alert");
      return;
    }

    let typePrefix = 'Medic';
    if (type === 2) typePrefix = 'Engine';
    else if (type === 3) typePrefix = 'Patrol';
    else if (type === 4) typePrefix = 'Ladder';
    else if (type === 5) typePrefix = 'BearCat';

    for (let i = 0; i < quantity; i++) {
      const vehicleId = this.vehicleCounter++;
      const callsign = customName 
        ? (quantity > 1 ? `${customName}-${i + 1}` : customName)
        : `${typePrefix}-${vehicleId}`;

      // Stagger convoy start times so vehicles don't overlap as identical points
      const staggerProgress = quantity > 1 ? -(i * 0.14) : 0;

      const newVehicle = {
        id: vehicleId,
        callsign: callsign,
        type: type,
        typeName: this.getVehicleTypeName(type),
        urgency: urgency,
        priorityScore: priorityScore,
        isPreemptEligible: priorityScore >= this.PREEMPTION_LIMIT,
        startNode: startId,
        destNode: destId,
        currentNode: startId,
        targetNode: routeData.route[1],
        route: routeData.route,
        routeIndex: 0,
        totalCost: routeData.totalCost,
        costRemaining: routeData.totalCost,
        progress: staggerProgress,
        state: 'en_route',
        speed: 0.008 + (priorityScore / 4500)
      };

      this.activeVehicles.push(newVehicle);
      if (staggerProgress >= 0) {
        this.checkVehiclePreemption(newVehicle);
      }
    }

    this.sound.playDispatchChirp();
    this.log(`🚨 [DISPATCHED ${quantity} UNIT(S)] ${quantity}x ${this.getVehicleTypeName(type)} en route from [${startId}] to [${destId}]. Priority: ${priorityScore} | Route: [${routeData.route.join(' -> ')}] (Cost: ${routeData.totalCost})`, "system");

    this.renderActiveFleet();
    this.updateStatsDisplay();

    if (!this.isPlaying) {
      this.togglePlayPause(true);
    }
  }

  // ==========================================================================
  // MIXED FLEET TASK FORCE BUILDER
  // ==========================================================================
  updateTaskForceTotalDisplay() {
    const amb = parseInt(document.getElementById('tf-amb')?.value || '0', 10);
    const fire = parseInt(document.getElementById('tf-fire')?.value || '0', 10);
    const ladder = parseInt(document.getElementById('tf-ladder')?.value || '0', 10);
    const police = parseInt(document.getElementById('tf-police')?.value || '0', 10);
    const swat = parseInt(document.getElementById('tf-swat')?.value || '0', 10);
    const total = amb + fire + ladder + police + swat;
    const disp = document.getElementById('tfTotalCountDisplay');
    if (disp) disp.textContent = total;
  }

  deployCustomTaskForce() {
    if (this.nodes.length < 2) return;

    const ambCount = parseInt(document.getElementById('tf-amb')?.value || '0', 10);
    const fireCount = parseInt(document.getElementById('tf-fire')?.value || '0', 10);
    const ladderCount = parseInt(document.getElementById('tf-ladder')?.value || '0', 10);
    const policeCount = parseInt(document.getElementById('tf-police')?.value || '0', 10);
    const swatCount = parseInt(document.getElementById('tf-swat')?.value || '0', 10);
    const targetDest = parseInt(document.getElementById('tfDestNodeSelect')?.value || '0', 10);
    const strategy = document.getElementById('tfDeployStrategy')?.value || 'distributed';

    const totalUnits = ambCount + fireCount + ladderCount + policeCount + swatCount;
    if (totalUnits === 0) {
      alert("Please select at least 1 unit to deploy in the Task Force!");
      return;
    }

    const fleetRoster = [];
    for (let i = 0; i < ambCount; i++) fleetRoster.push({ type: 1, urgency: 5, prefix: `Medic-TF${i + 1}` });
    for (let i = 0; i < ladderCount; i++) fleetRoster.push({ type: 4, urgency: 5, prefix: `Ladder-TF${i + 1}` });
    for (let i = 0; i < fireCount; i++) fleetRoster.push({ type: 2, urgency: 4, prefix: `Engine-TF${i + 1}` });
    for (let i = 0; i < swatCount; i++) fleetRoster.push({ type: 5, urgency: 5, prefix: `BearCat-TF${i + 1}` });
    for (let i = 0; i < policeCount; i++) fleetRoster.push({ type: 3, urgency: 4, prefix: `Patrol-TF${i + 1}` });

    const nodeIds = this.nodes.map(n => n.id);
    const possibleOrigins = nodeIds.filter(id => id !== targetDest);
    if (possibleOrigins.length === 0) possibleOrigins.push(nodeIds[0]);

    let deployedCount = 0;
    fleetRoster.forEach((spec, idx) => {
      let orig = possibleOrigins[0];
      if (strategy === 'distributed') {
        orig = possibleOrigins[idx % possibleOrigins.length];
      }

      const routeData = DijkstraRouter.findRoute(this.nodes, this.roads, orig, targetDest);
      if (routeData.route.length >= 2) {
        const vId = this.vehicleCounter++;
        const priority = this.calculatePriorityScore(spec.type, spec.urgency);
        const stagger = -(idx * 0.12);

        this.activeVehicles.push({
          id: vId,
          callsign: spec.prefix,
          type: spec.type,
          typeName: this.getVehicleTypeName(spec.type),
          urgency: spec.urgency,
          priorityScore: priority,
          isPreemptEligible: priority >= this.PREEMPTION_LIMIT,
          startNode: orig,
          destNode: targetDest,
          currentNode: orig,
          targetNode: routeData.route[1],
          route: routeData.route,
          routeIndex: 0,
          totalCost: routeData.totalCost,
          costRemaining: routeData.totalCost,
          progress: stagger,
          state: 'en_route',
          speed: 0.008 + (priority / 4200)
        });
        deployedCount++;
      }
    });

    if (deployedCount > 0) {
      this.sound.playSirenYelp();
      this.log(`🚀 [TASK FORCE DEPLOYED] Converging mixed fleet of ${deployedCount} emergency units on Incident Junction [${targetDest}]! Strategy: ${strategy.toUpperCase()}.`, "system");
      this.activeVehicles.forEach(v => {
        if (v.progress >= 0) this.checkVehiclePreemption(v);
      });
      this.renderActiveFleet();
      this.updateStatsDisplay();

      if (!this.isPlaying) {
        this.togglePlayPause(true);
      }
    } else {
      alert("Could not find open road routes from origins to target destination!");
    }
  }

  // ==========================================================================
  // MULTI-DESTINATION DISPATCH (Send different vehicles to different nodes)
  // ==========================================================================
  setupMultiDispatch() {
    document.getElementById('btnAddMultiRow')?.addEventListener('click', () => this.addMultiDispatchRow());
    document.getElementById('btnDispatchMultiAll')?.addEventListener('click', () => this.dispatchAllMultiAssignments());
    // Seed with 2 starter rows
    this.addMultiDispatchRow();
    this.addMultiDispatchRow(1); // second row defaults type 2
  }

  _buildNodeOptions() {
    return this.nodes.map(n => `<option value="${n.id}">[${n.id}] ${n.name}</option>`).join('');
  }

  addMultiDispatchRow(defaultType) {
    const list = document.getElementById('multiDispatchList');
    if (!list) return;

    const rowId = `mdr-${Date.now()}-${Math.random().toString(36).slice(2,6)}`;
    const nodeOpts = this._buildNodeOptions();
    const defDest = this.nodes.length > 1 ? this.nodes[this.nodes.length - 1].id : 0;

    const typeOpts = [
      { v: 1, e: '🚑', n: 'Ambulance' },
      { v: 2, e: '🚒', n: 'Fire Pumper' },
      { v: 4, e: '🪜', n: 'Aerial Ladder' },
      { v: 3, e: '🚓', n: 'Police Cruiser' },
      { v: 5, e: '🚔', n: 'SWAT BearCat' }
    ].map(t => `<option value="${t.v}" ${(defaultType || 1) === t.v ? 'selected' : ''}>${t.e} ${t.n}</option>`).join('');

    const urgOpts = [1,2,3,4,5].map(u => `<option value="${u}" ${u===4?'selected':''}>${u}</option>`).join('');

    list.insertAdjacentHTML('beforeend', `
      <div class="md-row" id="${rowId}">
        <select class="md-type styled-select-sm">${typeOpts}</select>
        <span class="md-arrow">Urg</span>
        <select class="md-urgency styled-select-sm">${urgOpts}</select>
        <span class="md-arrow">From</span>
        <select class="md-origin styled-select-sm">${nodeOpts}</select>
        <span class="md-arrow">→</span>
        <select class="md-dest styled-select-sm">${nodeOpts}</select>
        <input class="md-callsign styled-input-sm" type="text" placeholder="Callsign">
        <button class="btn-md-remove" onclick="this.closest('.md-row').remove()" title="Remove">✕</button>
      </div>
    `);

    // Set dest to last node by default
    const row = document.getElementById(rowId);
    if (row && this.nodes.length > 1) {
      row.querySelector('.md-dest').value = defDest;
    }
  }

  dispatchAllMultiAssignments() {
    const list = document.getElementById('multiDispatchList');
    if (!list) return;

    const rows = list.querySelectorAll('.md-row');
    if (rows.length === 0) {
      alert('Add at least one vehicle assignment first!');
      return;
    }

    let dispatched = 0;
    let skipped = 0;

    rows.forEach((row, idx) => {
      const type    = parseInt(row.querySelector('.md-type').value, 10);
      const urgency = parseInt(row.querySelector('.md-urgency').value, 10);
      const startId = parseInt(row.querySelector('.md-origin').value, 10);
      const destId  = parseInt(row.querySelector('.md-dest').value, 10);
      const callsign = row.querySelector('.md-callsign').value.trim();

      if (startId === destId) { skipped++; return; }

      const routeData = DijkstraRouter.findRoute(this.nodes, this.roads, startId, destId);
      if (routeData.route.length < 2) { skipped++; return; }

      const priority = this.calculatePriorityScore(type, urgency);
      const vId = this.vehicleCounter++;
      let typePrefix = ['','Medic','Engine','Patrol','Ladder','BearCat'][type] || 'Unit';
      const cs = callsign || `${typePrefix}-MD${vId}`;

      this.activeVehicles.push({
        id: vId,
        callsign: cs,
        type, typeName: this.getVehicleTypeName(type),
        urgency, priorityScore: priority,
        isPreemptEligible: priority >= this.PREEMPTION_LIMIT,
        startNode: startId, destNode: destId,
        currentNode: startId,
        targetNode: routeData.route[1],
        route: routeData.route,
        routeIndex: 0,
        totalCost: routeData.totalCost,
        costRemaining: routeData.totalCost,
        progress: -(idx * 0.1),
        state: 'en_route',
        speed: 0.008 + (priority / 4500)
      });
      this.checkVehiclePreemption(this.activeVehicles[this.activeVehicles.length - 1]);
      dispatched++;
    });

    if (dispatched === 0) {
      alert(`No valid assignments found. Check origin ≠ destination and roads are open.`);
      return;
    }

    this.sound.playSirenYelp();
    this.log(`🗺️ [MULTI-DISPATCH] Sent ${dispatched} unit(s) to individual targets. ${skipped} row(s) skipped (same node or no route).`, 'system');
    this.renderActiveFleet();
    this.updateStatsDisplay();
    if (!this.isPlaying) this.togglePlayPause(true);
  }

  refreshMultiDispatchNodeOptions() {
    const list = document.getElementById('multiDispatchList');
    if (!list) return;
    const nodeOpts = this._buildNodeOptions();
    list.querySelectorAll('.md-row').forEach(row => {
      const prevOrigin = row.querySelector('.md-origin').value;
      const prevDest   = row.querySelector('.md-dest').value;
      row.querySelector('.md-origin').innerHTML = nodeOpts;
      row.querySelector('.md-dest').innerHTML   = nodeOpts;
      row.querySelector('.md-origin').value = prevOrigin;
      row.querySelector('.md-dest').value   = prevDest;
    });
  }

  // ==========================================================================
  // MULTI-VEHICLE MASS FLEET SCENARIOS
  // ==========================================================================
  dispatchScenario(scenarioType) {
    if (this.nodes.length < 2) return;
    const nodeIds = this.nodes.map(n => n.id);

    if (scenarioType === 'code3') {
      // Code-3 Rapid Response: 1 Ambulance + 1 Fire Pumper + 1 Police Cruiser
      const targetDest = Math.min(3, nodeIds[nodeIds.length - 1]);
      const specs = [
        { type: 1, urgency: 5, prefix: 'Medic-Rapid' },
        { type: 2, urgency: 4, prefix: 'Engine-Rapid' },
        { type: 3, urgency: 4, prefix: 'Patrol-Rapid' }
      ];

      specs.forEach((s, idx) => {
        const orig = nodeIds[(idx * 2 + 1) % nodeIds.length] === targetDest ? nodeIds[0] : nodeIds[(idx * 2 + 1) % nodeIds.length];
        const routeData = DijkstraRouter.findRoute(this.nodes, this.roads, orig, targetDest);
        if (routeData.route.length >= 2) {
          const vId = this.vehicleCounter++;
          const priority = this.calculatePriorityScore(s.type, s.urgency);
          this.activeVehicles.push({
            id: vId,
            callsign: s.prefix,
            type: s.type,
            typeName: this.getVehicleTypeName(s.type),
            urgency: s.urgency,
            priorityScore: priority,
            isPreemptEligible: true,
            startNode: orig,
            destNode: targetDest,
            currentNode: orig,
            targetNode: routeData.route[1],
            route: routeData.route,
            routeIndex: 0,
            totalCost: routeData.totalCost,
            costRemaining: routeData.totalCost,
            progress: -(idx * 0.1),
            state: 'en_route',
            speed: 0.009 + (priority / 4500)
          });
        }
      });
      this.log(`🚨 [CODE-3 DISPATCH] 3-Unit Rapid Response Convoy deployed converging on Junction [${targetDest}]!`, "system");

    } else if (scenarioType === 'ambulance_surge') {
      // 3 Ambulances converging on Trauma Center (Node 0)
      const targetDest = 0;
      const origins = nodeIds.filter(id => id !== targetDest).slice(0, 3);
      if (origins.length === 0) origins.push(nodeIds[1]);

      origins.forEach((orig, idx) => {
        const routeData = DijkstraRouter.findRoute(this.nodes, this.roads, orig, targetDest);
        if (routeData.route.length >= 2) {
          const vId = this.vehicleCounter++;
          const priority = this.calculatePriorityScore(1, 4 + (idx % 2));
          this.activeVehicles.push({
            id: vId,
            callsign: `Ambulance-Alpha${idx + 1}`,
            type: 1,
            typeName: "Ambulance",
            urgency: 4 + (idx % 2),
            priorityScore: priority,
            isPreemptEligible: true,
            startNode: orig,
            destNode: targetDest,
            currentNode: orig,
            targetNode: routeData.route[1],
            route: routeData.route,
            routeIndex: 0,
            totalCost: routeData.totalCost,
            costRemaining: routeData.totalCost,
            progress: -(idx * 0.08),
            state: 'en_route',
            speed: 0.009 + (priority / 4500)
          });
        }
      });
      this.log(`🚑 [MEDICAL SURGE EVENT] 3x Trauma Ambulances dispatched simultaneously converging on Hospital [Node ${targetDest}]!`, "system");

    } else if (scenarioType === 'fire_response') {
      // 4 Units: 2 Engines + 1 Ladder + 1 Medic converging on incident
      const targetDest = Math.min(4, nodeIds[nodeIds.length - 1]);
      const fleetSpecs = [
        { type: 2, urgency: 5, prefix: 'Engine-1' },
        { type: 2, urgency: 4, prefix: 'Engine-2' },
        { type: 4, urgency: 5, prefix: 'Ladder-3' },
        { type: 1, urgency: 4, prefix: 'Rescue-Medic' }
      ];

      fleetSpecs.forEach((spec, idx) => {
        const orig = nodeIds[(idx * 2 + 1) % nodeIds.length] === targetDest ? nodeIds[0] : nodeIds[(idx * 2 + 1) % nodeIds.length];
        const routeData = DijkstraRouter.findRoute(this.nodes, this.roads, orig, targetDest);
        if (routeData.route.length >= 2) {
          const vId = this.vehicleCounter++;
          const priority = this.calculatePriorityScore(spec.type, spec.urgency);
          this.activeVehicles.push({
            id: vId,
            callsign: spec.prefix,
            type: spec.type,
            typeName: this.getVehicleTypeName(spec.type),
            urgency: spec.urgency,
            priorityScore: priority,
            isPreemptEligible: true,
            startNode: orig,
            destNode: targetDest,
            currentNode: orig,
            targetNode: routeData.route[1],
            route: routeData.route,
            routeIndex: 0,
            totalCost: routeData.totalCost,
            costRemaining: routeData.totalCost,
            progress: -(idx * 0.1),
            state: 'en_route',
            speed: 0.008 + (priority / 4500)
          });
        }
      });
      this.log(`🚒 [3-ALARM STRUCTURE FIRE] 4 Fire & Rescue units deployed to Junction [${targetDest}]! Priority pre-emption active.`, "system");

    } else if (scenarioType === 'swat_siege') {
      // 5 Units: 2 SWAT BearCats + 2 Police Cruisers + 1 Medic
      const targetDest = Math.min(5, nodeIds[nodeIds.length - 1]);
      const specs = [
        { type: 5, urgency: 5, prefix: 'BearCat-Lead' },
        { type: 5, urgency: 5, prefix: 'BearCat-Support' },
        { type: 3, urgency: 4, prefix: 'Patrol-Perimeter1' },
        { type: 3, urgency: 4, prefix: 'Patrol-Perimeter2' },
        { type: 1, urgency: 5, prefix: 'Tactical-Medic' }
      ];

      specs.forEach((s, idx) => {
        const orig = nodeIds[(idx * 2 + 2) % nodeIds.length] === targetDest ? nodeIds[0] : nodeIds[(idx * 2 + 2) % nodeIds.length];
        const routeData = DijkstraRouter.findRoute(this.nodes, this.roads, orig, targetDest);
        if (routeData.route.length >= 2) {
          const vId = this.vehicleCounter++;
          const priority = this.calculatePriorityScore(s.type, s.urgency);
          this.activeVehicles.push({
            id: vId,
            callsign: s.prefix,
            type: s.type,
            typeName: this.getVehicleTypeName(s.type),
            urgency: s.urgency,
            priorityScore: priority,
            isPreemptEligible: true,
            startNode: orig,
            destNode: targetDest,
            currentNode: orig,
            targetNode: routeData.route[1],
            route: routeData.route,
            routeIndex: 0,
            totalCost: routeData.totalCost,
            costRemaining: routeData.totalCost,
            progress: -(idx * 0.12),
            state: 'en_route',
            speed: 0.009 + (priority / 4500)
          });
        }
      });
      this.log(`🚔 [SWAT TACTICAL SIEGE] 5 Heavy Tactical Units converging on Junction [${targetDest}] with full corridor pre-emption!`, "system");

    } else if (scenarioType === 'highway_pileup') {
      // 6 Units: 2 Ambulances + 2 Fire Trucks + 2 Police Cruisers
      const targetDest = Math.min(2, nodeIds[nodeIds.length - 1]);
      const specs = [
        { type: 1, urgency: 5, prefix: 'Trauma-Amb1' },
        { type: 1, urgency: 5, prefix: 'Trauma-Amb2' },
        { type: 2, urgency: 4, prefix: 'HeavyRescue-1' },
        { type: 4, urgency: 4, prefix: 'AerialLadder-2' },
        { type: 3, urgency: 4, prefix: 'HighwayPatrol-1' },
        { type: 3, urgency: 3, prefix: 'HighwayPatrol-2' }
      ];

      specs.forEach((s, idx) => {
        const orig = nodeIds[(idx + 1) % nodeIds.length] === targetDest ? nodeIds[0] : nodeIds[(idx + 1) % nodeIds.length];
        const routeData = DijkstraRouter.findRoute(this.nodes, this.roads, orig, targetDest);
        if (routeData.route.length >= 2) {
          const vId = this.vehicleCounter++;
          const priority = this.calculatePriorityScore(s.type, s.urgency);
          this.activeVehicles.push({
            id: vId,
            callsign: s.prefix,
            type: s.type,
            typeName: this.getVehicleTypeName(s.type),
            urgency: s.urgency,
            priorityScore: priority,
            isPreemptEligible: true,
            startNode: orig,
            destNode: targetDest,
            currentNode: orig,
            targetNode: routeData.route[1],
            route: routeData.route,
            routeIndex: 0,
            totalCost: routeData.totalCost,
            costRemaining: routeData.totalCost,
            progress: -(idx * 0.1),
            state: 'en_route',
            speed: 0.009 + (priority / 4500)
          });
        }
      });
      this.log(`💥 [HIGHWAY MULTI-VEHICLE PILEUP] 6 Emergency Units deployed across city grid converging on Junction [${targetDest}]!`, "system");

    } else if (scenarioType === 'random_fleet') {
      // 6 Diverse Units across random citywide stations
      const types = [1, 2, 3, 4, 5];
      for (let i = 0; i < 6; i++) {
        const t = types[i % types.length];
        const orig = nodeIds[i % nodeIds.length];
        const dest = nodeIds[(i + 3) % nodeIds.length];
        if (orig !== dest) {
          const routeData = DijkstraRouter.findRoute(this.nodes, this.roads, orig, dest);
          if (routeData.route.length >= 2) {
            const vId = this.vehicleCounter++;
            const urg = 3 + (i % 3);
            const priority = this.calculatePriorityScore(t, urg);
            this.activeVehicles.push({
              id: vId,
              callsign: `${this.getVehicleTypeName(t).split(' ')[0]}-Fleet${i + 1}`,
              type: t,
              typeName: this.getVehicleTypeName(t),
              urgency: urg,
              priorityScore: priority,
              isPreemptEligible: priority >= this.PREEMPTION_LIMIT,
              startNode: orig,
              destNode: dest,
              currentNode: orig,
              targetNode: routeData.route[1],
              route: routeData.route,
              routeIndex: 0,
              totalCost: routeData.totalCost,
              costRemaining: routeData.totalCost,
              progress: -(i * 0.08),
              state: 'en_route',
              speed: 0.008 + (priority / 4500)
            });
          }
        }
      }
      this.log(`🎲 [RANDOM FLEET DEPLOYMENT] 6 Diverse Emergency Units deployed citywide! Multi-junction priority arbitration active.`, "system");
    }

    this.sound.playSirenYelp();
    this.activeVehicles.forEach(v => {
      if (v.progress >= 0) this.checkVehiclePreemption(v);
    });
    this.renderActiveFleet();
    this.updateStatsDisplay();

    if (!this.isPlaying) {
      this.togglePlayPause(true);
    }
  }

  abortAllVehicles() {
    if (this.activeVehicles.length === 0) return;
    const count = this.activeVehicles.length;

    this.activeVehicles.forEach(v => {
      this.releaseVehiclePreemption(v, v.targetNode);
      this.releaseVehiclePreemption(v, v.currentNode);
    });

    this.activeVehicles = [];
    this.hidePreemptionBanner();
    this.log(`🛑 Operator cleared all ${count} active emergency dispatches. All signal pre-emptions released.`, "system");
    this.renderActiveFleet();
    this.updateStatsDisplay();
  }

  // ==========================================================================
  // SPATIAL DIRECTION HEADING & TRAFFIC SIGNAL PRE-EMPTION
  // ==========================================================================
  calculateSpatialApproach(fromNode, toNode) {
    const dx = toNode.x - fromNode.x;
    const dy = toNode.y - fromNode.y;

    const angleDeg = Math.atan2(-dy, dx) * (180 / Math.PI);
    let normalized = angleDeg;
    if (normalized < 0) normalized += 360;

    if (normalized >= 315 || normalized < 45) {
      return { dir: 'west', label: 'WEST APPROACH' };
    } else if (normalized >= 45 && normalized < 135) {
      return { dir: 'south', label: 'SOUTH APPROACH' };
    } else if (normalized >= 135 && normalized < 225) {
      return { dir: 'east', label: 'EAST APPROACH' };
    } else {
      return { dir: 'north', label: 'NORTH APPROACH' };
    }
  }

  showConflictArbitration(winnerVehicle, yieldingVehicle, junctionNode) {
    const hud = document.getElementById('conflictArbitrationHud');
    const desc = document.getElementById('conflictArbitrationDesc');
    if (!hud || !desc) return;

    desc.textContent = `${winnerVehicle.callsign} (${winnerVehicle.typeName}, Score ${winnerVehicle.priorityScore}) GRANTED GREEN corridor over ${yieldingVehicle.callsign} (${yieldingVehicle.typeName}, Score ${yieldingVehicle.priorityScore}) at Junction ${junctionNode.id}`;
    hud.classList.remove('hidden');

    if (this.conflictHudTimeout) clearTimeout(this.conflictHudTimeout);
    this.conflictHudTimeout = setTimeout(() => {
      hud.classList.add('hidden');
    }, 4500);

    this.sound.playAlertKlaxon();
  }

  checkVehiclePreemption(vehicle) {
    if (!vehicle.isPreemptEligible || vehicle.state !== 'en_route') return;

    const fromNode = this.nodes.find(n => n.id === vehicle.currentNode);
    const toNode = this.nodes.find(n => n.id === vehicle.targetNode);
    if (!fromNode || !toNode) return;

    const approach = this.calculateSpatialApproach(fromNode, toNode);

    // Multi-vehicle Conflict Arbitration at Junction
    if (toNode.signals.override && toNode.signals.override.vehicleId !== vehicle.id) {
      const other = this.activeVehicles.find(v => v.id === toNode.signals.override.vehicleId);
      if (other) {
        if (other.priorityScore > vehicle.priorityScore) {
          this.log(`⚠️ [PRE-EMPTION CONFLICT at Node ${toNode.id}] ${vehicle.callsign} (Score ${vehicle.priorityScore}) yields corridor to higher-priority ${other.callsign} (${other.priorityScore}).`, "reroute");
          this.showConflictArbitration(other, vehicle, toNode);
          return;
        } else if (vehicle.priorityScore > other.priorityScore) {
          this.log(`⚡ [PRE-EMPTION OVERRIDE at Node ${toNode.id}] ${vehicle.callsign} (Score ${vehicle.priorityScore}) OVERRIDES lower-priority ${other.callsign} (${other.priorityScore}).`, "preempt");
          this.showConflictArbitration(vehicle, other, toNode);
        }
      }
    }

    toNode.signals.override = {
      direction: approach.dir,
      vehicleId: vehicle.id,
      priorityScore: vehicle.priorityScore,
      approachLabel: approach.label
    };

    ['north', 'south', 'east', 'west'].forEach(d => {
      toNode.signals[d].state = (d === approach.dir) ? 'green' : 'red';
    });

    this.showPreemptionBanner(`${vehicle.callsign} approaching Junction ${toNode.id} from ${approach.label}. Priority Score: ${vehicle.priorityScore}.`);
    this.sound.playSirenYelp();

    this.log(`⚡ [PRE-EMPTION ACTUATED] Corridor locked at Intersection [${toNode.id}]. ${approach.label} -> FORCED GREEN. Conflicting traffic -> RED.`, "preempt");
    this.updateInspectorIfSelected(toNode.id);
  }

  releaseVehiclePreemption(vehicle, nodeId) {
    const node = this.nodes.find(n => n.id === nodeId);
    if (node && node.signals.override && node.signals.override.vehicleId === vehicle.id) {
      node.signals.override = null;
      this.log(`✅ [PRE-EMPTION RELEASED] Pre-emption cleared at Intersection [${nodeId}]. Normal signal cycling resumed.`, "system");
      this.hidePreemptionBanner();
      this.updateInspectorIfSelected(nodeId);
    }
  }

  showPreemptionBanner(text) {
    const banner = document.getElementById('preemptionBanner');
    const desc = document.getElementById('preemptionBannerText');
    if (banner && desc) {
      desc.textContent = text;
      banner.classList.remove('hidden');
    }
  }

  hidePreemptionBanner() {
    const banner = document.getElementById('preemptionBanner');
    if (banner) banner.classList.add('hidden');
  }

  // ==========================================================================
  // DYNAMIC MID-TRANSIT REROUTING (PHYSICALLY REALISTIC & SMOOTH)
  // Handles:
  // - Road blocked ahead while current road is clear (reroutes smoothly without resetting progress or teleporting)
  // - Road vehicle is currently traversing gets blocked (smooth 180° U-turn diversion or forward clearance)
  // - Road reopening / clearance (automatically rescues vehicles in 'holding' state)
  // - Disconnected network (safe holding pattern)
  // ==========================================================================
  rerouteAllActiveVehicles(reason = "Road modification") {
    let reroutedCount = 0;

    this.activeVehicles.forEach(vehicle => {
      if (vehicle.state === 'arrived') return;

      // 1. Identify active road segment
      const currentSegment = this.roads.find(r => 
        (r.from === vehicle.currentNode && r.to === vehicle.targetNode) ||
        (r.from === vehicle.targetNode && r.to === vehicle.currentNode)
      );
      const isCurrentRoadBlocked = currentSegment ? currentSegment.blocked : false;

      // 2. Road Clearance / Reopening Recovery
      if (vehicle.state === 'holding') {
        const recoveryRoute = DijkstraRouter.findRoute(this.nodes, this.roads, vehicle.currentNode, vehicle.destNode);
        if (recoveryRoute.route.length >= 2) {
          vehicle.state = 'en_route';
          vehicle.route = recoveryRoute.route;
          vehicle.routeIndex = 0;
          vehicle.targetNode = recoveryRoute.route[1];
          vehicle.progress = 0;
          vehicle.totalCost = recoveryRoute.totalCost;
          this.checkVehiclePreemption(vehicle);
          reroutedCount++;
          this.log(`🟢 [PATH RESTORED] Road reopened! ${vehicle.callsign} resumed navigation to Junction [${vehicle.destNode}] via [${recoveryRoute.route.join(' -> ')}] (Cost: ${recoveryRoute.totalCost}).`, "system");
          return;
        }
      }

      // 3. CASE A: Current road segment is OPEN
      if (!isCurrentRoadBlocked) {
        // If already on the final segment to destination, let it proceed
        if (vehicle.targetNode === vehicle.destNode) {
          return;
        }

        // Recompute optimal Dijkstra route from upcoming target junction to destination
        const nextRoute = DijkstraRouter.findRoute(this.nodes, this.roads, vehicle.targetNode, vehicle.destNode);

        if (nextRoute.route.length >= 2) {
          const currentRemaining = vehicle.route.slice(vehicle.routeIndex + 1);
          const isDifferent = currentRemaining.join(',') !== nextRoute.route.join(',');

          if (isDifferent) {
            // Smoothly stitch new path ahead. CURRENT PROGRESS REMAINS INTACT!
            vehicle.route = [vehicle.currentNode, ...nextRoute.route];
            vehicle.routeIndex = 0;
            vehicle.totalCost = (currentSegment ? currentSegment.cost : 0) + nextRoute.totalCost;
            vehicle.state = 'en_route';
            reroutedCount++;

            this.log(`🔄 [MID-TRANSIT REROUTE] Road obstruction detected ahead! ${vehicle.callsign} smoothly detouring via [${nextRoute.route.join(' -> ')}] (New Cost: ${vehicle.totalCost}). Continuing along current road without interruption.`, "reroute");
            this.checkVehiclePreemption(vehicle);
          }
        } else {
          // No route from upcoming junction! Can vehicle turn around at current junction?
          const backRoute = DijkstraRouter.findRoute(this.nodes, this.roads, vehicle.currentNode, vehicle.destNode);
          if (backRoute.route.length >= 2) {
            // Execute 180° U-turn diversion
            const oldTarget = vehicle.targetNode;
            vehicle.targetNode = vehicle.currentNode;
            vehicle.currentNode = oldTarget;
            vehicle.progress = Math.max(0, 1.0 - vehicle.progress);
            vehicle.route = [vehicle.currentNode, ...backRoute.route];
            vehicle.routeIndex = 0;
            vehicle.state = 'en_route';
            this.releaseVehiclePreemption(vehicle, oldTarget);
            this.checkVehiclePreemption(vehicle);
            reroutedCount++;

            this.log(`🚨 [U-TURN DIVERSION] Upcoming corridor from Node ${oldTarget} is blocked! ${vehicle.callsign} performed 180° diversion heading back to Node ${vehicle.targetNode} detour [${backRoute.route.join(' -> ')}].`, "reroute");
          } else {
            // Cut off from both sides
            vehicle.state = 'holding';
            this.log(`⚠️ [ROADBLOCKED] All paths to destination [${vehicle.destNode}] are blocked! ${vehicle.callsign} holding at current sector.`, "alert");
            this.sound.playAlertKlaxon();
          }
        }
      } 
      // 4. CASE B: The road the vehicle is CURRENTLY ON was just BLOCKED
      else {
        if (vehicle.progress < 0.6) {
          // Closer to start node: perform emergency 180° U-turn back to currentNode
          const backRoute = DijkstraRouter.findRoute(this.nodes, this.roads, vehicle.currentNode, vehicle.destNode);
          if (backRoute.route.length >= 2) {
            const oldTarget = vehicle.targetNode;
            vehicle.targetNode = vehicle.currentNode;
            vehicle.currentNode = oldTarget;
            vehicle.progress = Math.max(0, 1.0 - vehicle.progress);
            vehicle.route = [vehicle.currentNode, ...backRoute.route];
            vehicle.routeIndex = 0;
            vehicle.state = 'en_route';
            this.releaseVehiclePreemption(vehicle, oldTarget);
            this.checkVehiclePreemption(vehicle);
            reroutedCount++;

            this.log(`🚨 [IMMEDIATE HAZARD U-TURN] Active road blocked mid-transit! ${vehicle.callsign} executed emergency 180° turn back towards Node ${vehicle.targetNode} detour [${backRoute.route.join(' -> ')}].`, "reroute");
          } else {
            // Try forward clearance if path exists from targetNode
            const forwardRoute = DijkstraRouter.findRoute(this.nodes, this.roads, vehicle.targetNode, vehicle.destNode);
            if (forwardRoute.route.length >= 2) {
              vehicle.route = [vehicle.currentNode, ...forwardRoute.route];
              vehicle.routeIndex = 0;
              reroutedCount++;
              this.log(`⚠️ [HAZARD BYPASS] Road blocked on active segment! ${vehicle.callsign} clearing to Junction ${vehicle.targetNode} detour [${forwardRoute.route.join(' -> ')}].`, "reroute");
            } else {
              vehicle.state = 'holding';
              this.log(`⚠️ [HAZARD STOP] Road blocked mid-transit and no alternate escape path. ${vehicle.callsign} safely holding on segment.`, "alert");
              this.sound.playAlertKlaxon();
            }
          }
        } else {
          // Closer to target node: clear forward into target junction and divert
          const forwardRoute = DijkstraRouter.findRoute(this.nodes, this.roads, vehicle.targetNode, vehicle.destNode);
          if (forwardRoute.route.length >= 2) {
            vehicle.route = [vehicle.currentNode, ...forwardRoute.route];
            vehicle.routeIndex = 0;
            reroutedCount++;
            this.log(`🔄 [MID-TRANSIT CLEARANCE] Road blocked behind. ${vehicle.callsign} clearing into Junction ${vehicle.targetNode} and detouring via [${forwardRoute.route.join(' -> ')}].`, "reroute");
          } else {
            // Try U-turn back to currentNode
            const backRoute = DijkstraRouter.findRoute(this.nodes, this.roads, vehicle.currentNode, vehicle.destNode);
            if (backRoute.route.length >= 2) {
              const oldTarget = vehicle.targetNode;
              vehicle.targetNode = vehicle.currentNode;
              vehicle.currentNode = oldTarget;
              vehicle.progress = Math.max(0, 1.0 - vehicle.progress);
              vehicle.route = [vehicle.currentNode, ...backRoute.route];
              vehicle.routeIndex = 0;
              this.releaseVehiclePreemption(vehicle, oldTarget);
              this.checkVehiclePreemption(vehicle);
              reroutedCount++;
              this.log(`🚨 [EMERGENCY U-TURN] Junction ${oldTarget} exit blocked! ${vehicle.callsign} executed 180° turn back to Node ${vehicle.targetNode}.`, "reroute");
            } else {
              vehicle.state = 'holding';
              this.log(`⚠️ [ROADBLOCKED] Road blocked and no escape from Junction ${vehicle.targetNode}. ${vehicle.callsign} holding.`, "alert");
              this.sound.playAlertKlaxon();
            }
          }
        }
      }
    });

    if (reroutedCount > 0) {
      this.sound.playAlertKlaxon();
      this.renderActiveFleet();
      if (this.city3D) this.city3D.update3DCorridors();
    }
  }

  stepOneHop() {
    if (this.activeVehicles.length === 0) {
      alert("No active emergency vehicles dispatched! Dispatch a vehicle first.");
      return;
    }

    this.activeVehicles.forEach(v => {
      if (v.state === 'arrived' || v.state === 'holding') return;

      const arrivedNodeId = v.targetNode;
      v.currentNode = arrivedNodeId;
      v.routeIndex++;

      if (v.currentNode === v.destNode || v.routeIndex >= v.route.length - 1) {
        v.state = 'arrived';
        v.progress = 1.0;
        this.releaseVehiclePreemption(v, arrivedNodeId);
        this.sound.playArrivalChime();
        this.log(`🎉 [DESTINATION REACHED] ${v.callsign} arrived at destination Junction [${v.destNode}]! Total Cost: ${v.totalCost}`, "arrival");
      } else {
        v.targetNode = v.route[v.routeIndex + 1];
        v.progress = 0;
        this.releaseVehiclePreemption(v, arrivedNodeId);
        this.checkVehiclePreemption(v);
      }
    });

    this.renderActiveFleet();
    this.updateStatsDisplay();
  }

  updateSimulation(deltaTime) {
    if (!this.isPlaying || this.activeVehicles.length === 0) return;

    this.activeVehicles.forEach(v => {
      if (v.state !== 'en_route') return;

      v.progress += v.speed * this.simSpeed * (deltaTime / 16.6);

      if (v.progress >= 1.0) {
        const arrivedNodeId = v.targetNode;
        v.currentNode = arrivedNodeId;
        v.routeIndex++;

        if (v.currentNode === v.destNode || v.routeIndex >= v.route.length - 1) {
          v.state = 'arrived';
          v.progress = 1.0;
          this.releaseVehiclePreemption(v, arrivedNodeId);
          this.sound.playArrivalChime();
          this.log(`🎉 [MISSION SUCCESS] ${v.callsign} arrived at destination Junction [${v.destNode}]!`, "arrival");
        } else {
          v.targetNode = v.route[v.routeIndex + 1];
          v.progress = 0;
          this.releaseVehiclePreemption(v, arrivedNodeId);
          this.checkVehiclePreemption(v);
        }

        this.renderActiveFleet();
        this.updateStatsDisplay();
      }
    });
  }

  // ==========================================================================
  // TRAFFIC SIGNAL AUTONOMOUS CLOCK
  // ==========================================================================
  setupSignalClock() {
    setInterval(() => {
      this.nodes.forEach(node => {
        if (node.signals.override) return;

        node.signals.cycleTimer += 1;
        const t = node.signals.cycleTimer % 40;

        if (t < 15) {
          node.signals.east.state = 'green';
          node.signals.west.state = 'green';
          node.signals.north.state = 'red';
          node.signals.south.state = 'red';
          node.signals.east.timer = 15 - t;
          node.signals.west.timer = 15 - t;
        } else if (t < 18) {
          node.signals.east.state = 'yellow';
          node.signals.west.state = 'yellow';
          node.signals.north.state = 'red';
          node.signals.south.state = 'red';
        } else if (t < 20) {
          node.signals.east.state = 'red';
          node.signals.west.state = 'red';
          node.signals.north.state = 'red';
          node.signals.south.state = 'red';
        } else if (t < 35) {
          node.signals.north.state = 'green';
          node.signals.south.state = 'green';
          node.signals.east.state = 'red';
          node.signals.west.state = 'red';
          node.signals.north.timer = 35 - t;
          node.signals.south.timer = 35 - t;
        } else if (t < 38) {
          node.signals.north.state = 'yellow';
          node.signals.south.state = 'yellow';
          node.signals.east.state = 'red';
          node.signals.west.state = 'red';
        } else {
          node.signals.east.state = 'red';
          node.signals.west.state = 'red';
          node.signals.north.state = 'red';
          node.signals.south.state = 'red';
        }
      });

      if (this.selectedNodeId !== null) {
        this.updateInspectorIfSelected(this.selectedNodeId);
      }
    }, 1000);
  }

  // ==========================================================================
  // 2D CANVAS TACTICAL RENDERER (Fallback & Tactical Mode)
  // ==========================================================================
  render2D() {
    const { ctx2D: ctx, canvas2D: canvas } = this;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    ctx.translate(this.panX, this.panY);
    ctx.scale(this.zoom, this.zoom);

    // Draw Roads
    this.roads.forEach(r => {
      const u = this.nodes.find(n => n.id === r.from);
      const v = this.nodes.find(n => n.id === r.to);
      if (!u || !v) return;

      ctx.save();
      ctx.lineWidth = 12;
      ctx.strokeStyle = r.blocked ? '#ef4444' : (r.cost >= 30 ? '#f59e0b' : '#1e293b');
      ctx.beginPath();
      ctx.moveTo(u.x, u.y);
      ctx.lineTo(v.x, v.y);
      ctx.stroke();

      if (this.showCosts) {
        const mx = (u.x + v.x) / 2;
        const my = (u.y + v.y) / 2;
        ctx.fillStyle = '#38bdf8';
        ctx.font = '10px "JetBrains Mono", monospace';
        ctx.fillText(r.blocked ? '⛔' : `${r.cost}`, mx - 6, my - 6);
      }
      ctx.restore();
    });

    // Draw Corridors
    this.activeVehicles.forEach(v => {
      if (v.state === 'en_route') {
        ctx.save();
        ctx.lineWidth = 4;
        ctx.strokeStyle = '#10b981';
        ctx.setLineDash([8, 4]);
        ctx.beginPath();
        v.route.forEach((id, idx) => {
          const n = this.nodes.find(node => node.id === id);
          if (n) {
            if (idx === 0) ctx.moveTo(n.x, n.y);
            else ctx.lineTo(n.x, n.y);
          }
        });
        ctx.stroke();
        ctx.restore();
      }
    });

    // Draw Nodes
    this.nodes.forEach(n => {
      ctx.save();
      ctx.beginPath();
      ctx.arc(n.x, n.y, 16, 0, Math.PI * 2);
      ctx.fillStyle = n.signals.override ? '#064e3b' : '#0f172a';
      ctx.fill();
      ctx.strokeStyle = n.signals.override ? '#10b981' : '#334155';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = '#fff';
      ctx.font = 'bold 11px "Chakra Petch", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`${n.id}`, n.x, n.y);
      ctx.restore();
    });

    // Draw Vehicles
    this.activeVehicles.forEach(v => {
      if (v.state === 'arrived') return;
      const u = this.nodes.find(n => n.id === v.currentNode);
      const target = this.nodes.find(n => n.id === v.targetNode);
      if (!u || !target) return;

      const p = Math.min(Math.max(v.progress, 0), 1);
      const cx = u.x + (target.x - u.x) * p;
      const cy = u.y + (target.y - u.y) * p;

      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, 8, 0, Math.PI * 2);
      ctx.fillStyle = v.type === 1 ? '#ff2a55' : (v.type === 2 ? '#ff7b00' : '#00a2ff');
      ctx.fill();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();
    });

    ctx.restore();
  }

  // ==========================================================================
  // EVENT LISTENERS & UI SETUP
  // ==========================================================================
  setupEventListeners() {
    window.addEventListener('resize', () => this.resizeCanvas());

    // Scenario Preset Picker
    document.getElementById('mapPresetSelect')?.addEventListener('change', (e) => {
      this.loadPreset(e.target.value);
    });

    // Reset Simulation Button
    document.getElementById('btnResetSimulation')?.addEventListener('click', () => {
      this.loadPreset(this.currentPresetKey);
      this.log("🔄 Network state reset.", "system");
    });

    // Sound Toggle
    document.getElementById('btnSoundToggle')?.addEventListener('click', () => {
      this.sound.enabled = !this.sound.enabled;
      document.getElementById('soundIcon').textContent = this.sound.enabled ? '🔊' : '🔇';
      this.log(`Simulation audio ${this.sound.enabled ? 'ENABLED' : 'MUTED'}.`, "system");
    });

    // Left Panel Tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.getAttribute('data-tab'))?.classList.add('active');
      });
    });

    // Right Panel Tabs
    document.querySelectorAll('.tab-btn-r').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn-r').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content-r').forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.getAttribute('data-tab-r'))?.classList.add('active');
      });
    });

    // Vehicle Type Selector Cards
    document.querySelectorAll('.type-card').forEach(card => {
      card.addEventListener('click', () => {
        document.querySelectorAll('.type-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        const radio = card.querySelector('input[type="radio"]');
        if (radio) radio.checked = true;
        this.updatePriorityPreview();
      });
    });

    // Urgency Slider
    document.getElementById('urgencySlider')?.addEventListener('input', (e) => {
      const val = parseInt(e.target.value, 10);
      const labels = [
        "Level 1 (Routine)",
        "Level 2 (Urgent Call)",
        "Level 3 (High Severity)",
        "Level 4 (Life Threat)",
        "Level 5 (Mass Casualty)"
      ];
      document.getElementById('urgencyValueDisplay').textContent = labels[val - 1];
      this.updatePriorityPreview();
    });

    // Quantity Stepper & Chips
    const qtyInput = document.getElementById('vehicleQuantityInput');
    const qtyDisplay = document.getElementById('quantityDisplay');

    const updateQty = (val) => {
      const clamped = Math.min(Math.max(val, 1), 10);
      if (qtyInput) qtyInput.value = clamped;
      if (qtyDisplay) qtyDisplay.textContent = `${clamped} Unit${clamped > 1 ? 's' : ''}`;
      document.querySelectorAll('.btn-qty-chip').forEach(c => {
        c.classList.toggle('active', parseInt(c.getAttribute('data-qty'), 10) === clamped);
      });
    };

    document.getElementById('btnQtyMinus')?.addEventListener('click', () => {
      const cur = parseInt(qtyInput?.value || '1', 10);
      updateQty(cur - 1);
    });

    document.getElementById('btnQtyPlus')?.addEventListener('click', () => {
      const cur = parseInt(qtyInput?.value || '1', 10);
      updateQty(cur + 1);
    });

    qtyInput?.addEventListener('input', (e) => {
      updateQty(parseInt(e.target.value || '1', 10));
    });

    document.querySelectorAll('.btn-qty-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        const q = parseInt(e.target.getAttribute('data-qty'), 10);
        updateQty(q);
      });
    });

    // Mixed Fleet Task Force Builder
    document.querySelectorAll('.btn-roster-step').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const targetId = e.currentTarget.getAttribute('data-target');
        const dir = parseInt(e.currentTarget.getAttribute('data-dir'), 10);
        const input = document.getElementById(targetId);
        if (input) {
          let val = parseInt(input.value || '0', 10) + dir;
          val = Math.max(0, Math.min(6, val));
          input.value = val;
          this.updateTaskForceTotalDisplay();
        }
      });
    });

    document.getElementById('btnDeployCustomTaskForce')?.addEventListener('click', () => {
      this.deployCustomTaskForce();
    });

    // Pre-Configured Mixed Fleet Scenarios
    document.getElementById('btnScenarioCode3')?.addEventListener('click', () => {
      this.dispatchScenario('code3');
    });

    document.getElementById('btnScenarioAmbulanceFleet')?.addEventListener('click', () => {
      this.dispatchScenario('ambulance_surge');
    });

    document.getElementById('btnScenarioFireResponse')?.addEventListener('click', () => {
      this.dispatchScenario('fire_response');
    });

    document.getElementById('btnScenarioSwatSiege')?.addEventListener('click', () => {
      this.dispatchScenario('swat_siege');
    });

    document.getElementById('btnScenarioHighwayPileup')?.addEventListener('click', () => {
      this.dispatchScenario('highway_pileup');
    });

    document.getElementById('btnScenarioRandomFleet')?.addEventListener('click', () => {
      this.dispatchScenario('random_fleet');
    });

    // Camera Cycle Buttons
    document.getElementById('btnPrevVehicleCam')?.addEventListener('click', () => {
      if (this.city3D) this.city3D.cycleVehicleCam(-1);
    });

    document.getElementById('btnNextVehicleCam')?.addEventListener('click', () => {
      if (this.city3D) this.city3D.cycleVehicleCam(1);
    });

    // Layer Toggles
    document.getElementById('btnToggleSignals')?.addEventListener('click', (e) => {
      this.showSignals = !this.showSignals;
      e.currentTarget.classList.toggle('active', this.showSignals);
      if (this.city3D) this.city3D.signalsGroup.visible = this.showSignals;
    });

    document.getElementById('btnToggleCosts')?.addEventListener('click', (e) => {
      this.showCosts = !this.showCosts;
      e.currentTarget.classList.toggle('active', this.showCosts);
    });

    // Abort / Clear All Active Fleet
    document.getElementById('btnAbortAllVehicles')?.addEventListener('click', () => {
      this.abortAllVehicles();
    });

    // Dispatch Vehicle Button
    document.getElementById('btnDispatchVehicle')?.addEventListener('click', () => {
      this.dispatchVehicle();
    });

    // Play / Pause Simulation
    document.getElementById('btnPlayPause')?.addEventListener('click', () => {
      this.togglePlayPause();
    });

    // Step 1 Hop
    document.getElementById('btnStepSimulation')?.addEventListener('click', () => {
      this.stepOneHop();
    });

    // Sim Speed
    document.getElementById('simSpeedSelect')?.addEventListener('change', (e) => {
      this.simSpeed = parseFloat(e.target.value);
    });

    // 3D vs 2D Mode Switcher
    document.getElementById('btnView3D')?.addEventListener('click', () => {
      this.setViewMode('3d');
    });
    document.getElementById('btnView2D')?.addEventListener('click', () => {
      this.setViewMode('2d');
    });

    // 3D Camera Selector
    document.getElementById('camera3DSelect')?.addEventListener('change', (e) => {
      if (this.city3D) this.city3D.setCameraMode(e.target.value);
    });

    // Day / Night Toggle
    document.getElementById('btnToggleTimeOfDay')?.addEventListener('click', () => {
      if (this.city3D) {
        this.city3D.isNightMode = !this.city3D.isNightMode;
        this.city3D.applyTimeOfDay();
        document.getElementById('todIcon').textContent = this.city3D.isNightMode ? '🌙 Night' : '☀️ Day';
        this.log(`Environment lighting switched to ${this.city3D.isNightMode ? 'Night Neon' : 'Daylight'}.`, "system");
      }
    });

    // Reset View Button
    document.getElementById('btnFitView')?.addEventListener('click', () => {
      if (this.viewMode === '3d' && this.city3D) {
        this.city3D.setCameraMode('orbit');
      } else {
        this.centerView2D();
      }
    });

    // Toggle 3D Buildings
    document.getElementById('btnToggleBuildings')?.addEventListener('click', (e) => {
      this.showBuildings = !this.showBuildings;
      e.target.classList.toggle('active', this.showBuildings);
      if (this.city3D) this.city3D.buildingsGroup.visible = this.showBuildings;
    });

    // Incident Buttons
    document.getElementById('btnRandomIncident')?.addEventListener('click', () => this.triggerRandomIncident());
    document.getElementById('btnClearAllIncidents')?.addEventListener('click', () => this.clearAllRoadblocks());

    // Signal Manual Overrides
    document.querySelectorAll('.btn-preempt-override').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const dir = e.target.getAttribute('data-dir');
        this.manualPreemptSelectedNode(dir);
      });
    });
    document.getElementById('btnReleaseOverride')?.addEventListener('click', () => {
      this.releaseSelectedNodeOverride();
    });

    // Unit Tests Runner
    document.getElementById('btnRunAutomatedTests')?.addEventListener('click', () => {
      this.runTestSuite();
    });

    // Logs Controls
    document.getElementById('btnClearLogs')?.addEventListener('click', () => {
      document.getElementById('systemLogOutput').innerHTML = '';
    });
    document.getElementById('btnExpandLogs')?.addEventListener('click', () => {
      document.querySelector('.bottom-console-drawer')?.classList.toggle('collapsed');
    });

    // Modal Handlers
    this.setupRoadModalHandlers();
    this.setupCppCodeViewer();

    this.updatePriorityPreview();
  }

  setViewMode(mode) {
    this.viewMode = mode;
    const btn3D = document.getElementById('btnView3D');
    const btn2D = document.getElementById('btnView2D');
    const threeContainer = document.getElementById('threeContainer');
    const canvas2D = document.getElementById('cityMapCanvas');
    const camControls = document.getElementById('camera3DControls');
    const hint = document.getElementById('hud3DHint');

    if (mode === '3d') {
      btn3D?.classList.add('active');
      btn2D?.classList.remove('active');
      threeContainer?.classList.remove('hidden');
      canvas2D?.classList.add('hidden');
      if (camControls) camControls.style.display = 'flex';
      if (hint) hint.classList.remove('hidden');
      this.log("🎮 3D Cinematic City View engaged.", "system");
    } else {
      btn2D?.classList.add('active');
      btn3D?.classList.remove('active');
      threeContainer?.classList.add('hidden');
      canvas2D?.classList.remove('hidden');
      if (camControls) camControls.style.display = 'none';
      if (hint) hint.classList.add('hidden');
      this.centerView2D();
      this.log("🗺️ 2D Tactical Grid View engaged.", "system");
    }
  }

  resizeCanvas() {
    const container = document.getElementById('canvasContainer');
    if (!container) return;
    this.canvas2D.width = container.clientWidth;
    this.canvas2D.height = container.clientHeight;
    if (this.city3D) this.city3D.resize();
  }

  centerView2D() {
    if (this.nodes.length === 0) return;
    const minX = Math.min(...this.nodes.map(n => n.x));
    const maxX = Math.max(...this.nodes.map(n => n.x));
    const minY = Math.min(...this.nodes.map(n => n.y));
    const maxY = Math.max(...this.nodes.map(n => n.y));

    const w = maxX - minX + 200;
    const h = maxY - minY + 200;
    const zx = this.canvas2D.width / w;
    const zy = this.canvas2D.height / h;
    this.zoom = Math.min(Math.max(Math.min(zx, zy), 0.6), 1.5);

    this.panX = (this.canvas2D.width - (maxX + minX) * this.zoom) / 2;
    this.panY = (this.canvas2D.height - (maxY + minY) * this.zoom) / 2;
  }

  togglePlayPause(forcePlay = null) {
    this.isPlaying = forcePlay !== null ? forcePlay : !this.isPlaying;
    const btn = document.getElementById('btnPlayPause');
    const icon = document.getElementById('playPauseIcon');
    const text = document.getElementById('playPauseText');

    if (this.isPlaying) {
      btn?.classList.add('playing');
      if (icon) icon.textContent = '⏸';
      if (text) text.textContent = 'Pause Sim';
      this.log("▶ Continuous simulation started.", "system");
    } else {
      btn?.classList.remove('playing');
      if (icon) icon.textContent = '▶';
      if (text) text.textContent = 'Play Sim';
      this.log("⏸ Simulation paused.", "system");
    }
  }

  updatePriorityPreview() {
    const type = parseInt(document.querySelector('input[name="vehicleType"]:checked')?.value || '1', 10);
    const urgency = parseInt(document.getElementById('urgencySlider')?.value || '4', 10);
    const score = this.calculatePriorityScore(type, urgency);

    const scoreDisplay = document.getElementById('calcScoreDisplay');
    const badge = document.getElementById('preemptEligibilityBadge');

    if (scoreDisplay) scoreDisplay.textContent = score;

    if (badge) {
      if (score >= this.PREEMPTION_LIMIT) {
        badge.innerHTML = `<span class="status-indicator-dot green-dot"></span><span class="status-text">PRE-EMPTION ELIGIBLE (≥ ${this.PREEMPTION_LIMIT})</span>`;
      } else {
        badge.innerHTML = `<span class="status-indicator-dot red-dot"></span><span class="status-text" style="color:#ef4444">NORMAL CYCLE ONLY (&lt; ${this.PREEMPTION_LIMIT})</span>`;
      }
    }
  }

  // ==========================================================================
  // ROAD INVENTORY & MODAL
  // ==========================================================================
  renderRoadInventoryList() {
    const list = document.getElementById('roadInventoryList');
    const countBadge = document.getElementById('roadListCount');
    if (!list) return;

    if (countBadge) countBadge.textContent = this.roads.length;
    list.innerHTML = '';

    this.roads.forEach(road => {
      const u = this.nodes.find(n => n.id === road.from);
      const v = this.nodes.find(n => n.id === road.to);
      const row = document.createElement('div');
      row.className = `road-item-row ${road.blocked ? 'blocked' : ''}`;
      row.innerHTML = `
        <span class="road-item-name">[Road ${road.id}] ${u?.name || road.from} ⟷ ${v?.name || road.to}</span>
        <div class="road-item-meta">
          <span class="road-cost-badge">Cost: ${road.cost}</span>
          <span class="road-status-badge ${road.blocked ? 'closed' : 'open'}">
            ${road.blocked ? '🚫 BLOCKED' : 'OPEN'}
          </span>
        </div>
      `;
      row.addEventListener('click', () => this.openRoadModal(road.id));
      list.appendChild(row);
    });
  }

  openRoadModal(roadId) {
    const road = this.roads.find(r => r.id === roadId);
    if (!road) return;

    this.selectedRoadId = roadId;
    const u = this.nodes.find(n => n.id === road.from);
    const v = this.nodes.find(n => n.id === road.to);

    document.getElementById('modalRoadTitle').textContent = `Configure Road Link #${road.id}`;
    document.getElementById('modalRoadNodes').textContent = `[${road.from}] ${u?.name || 'Jct'} ⟷ [${road.to}] ${v?.name || 'Jct'}`;

    const statusEl = document.getElementById('modalRoadStatus');
    statusEl.textContent = road.blocked ? 'BLOCKED - NO TRAFFIC' : 'PASSABLE - OPEN';
    statusEl.className = road.blocked ? 'status-blocked text-alert' : 'status-open text-preempt';

    document.getElementById('modalCostInput').value = road.cost;

    const blockBtnText = document.getElementById('blockRoadBtnText');
    const blockBtnIcon = document.getElementById('blockRoadBtnIcon');
    if (road.blocked) {
      blockBtnText.textContent = 'Reopen Road';
      blockBtnIcon.textContent = '✅';
    } else {
      blockBtnText.textContent = 'Block Road';
      blockBtnIcon.textContent = '🚫';
    }

    document.getElementById('roadModal').classList.remove('hidden');
  }

  setupRoadModalHandlers() {
    document.getElementById('btnCloseModal')?.addEventListener('click', () => {
      document.getElementById('roadModal').classList.add('hidden');
      this.selectedRoadId = null;
    });

    document.querySelectorAll('.btn-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        const cost = e.target.getAttribute('data-cost');
        document.getElementById('modalCostInput').value = cost;
      });
    });

    document.getElementById('btnToggleBlockRoad')?.addEventListener('click', () => {
      const road = this.roads.find(r => r.id === this.selectedRoadId);
      if (!road) return;

      road.blocked = !road.blocked;
      this.log(`🚧 Road [${road.id}] is now ${road.blocked ? 'BLOCKED' : 'REOPENED'}.`, road.blocked ? 'alert' : 'system');
      document.getElementById('roadModal').classList.add('hidden');
      this.renderRoadInventoryList();
      if (this.city3D) this.city3D.updateRoads();
      this.rerouteAllActiveVehicles(road.blocked ? "road blockage" : "road reopening");
    });

    document.getElementById('btnSaveRoadCost')?.addEventListener('click', () => {
      const road = this.roads.find(r => r.id === this.selectedRoadId);
      if (!road) return;

      const newCost = parseInt(document.getElementById('modalCostInput').value, 10);
      if (newCost <= 0) {
        alert("Cost must be strictly greater than 0!");
        return;
      }

      const oldCost = road.cost;
      road.cost = newCost;
      this.log(`📈 Road [${road.id}] travel cost updated from ${oldCost} to ${newCost}.`, "system");
      document.getElementById('roadModal').classList.add('hidden');
      this.renderRoadInventoryList();
      if (this.city3D) this.city3D.updateRoads();
      this.rerouteAllActiveVehicles("traffic congestion update");
    });
  }

  triggerRandomIncident() {
    const openRoads = this.roads.filter(r => !r.blocked);
    if (openRoads.length === 0) {
      alert("All roads are already blocked!");
      return;
    }

    const randomRoad = openRoads[Math.floor(Math.random() * openRoads.length)];
    randomRoad.blocked = true;

    this.sound.playAlertKlaxon();
    this.log(`⚠️ [INCIDENT] Sudden road blockage on Road [${randomRoad.id}] between Junctions ${randomRoad.from} and ${randomRoad.to}!`, "alert");

    this.renderRoadInventoryList();
    if (this.city3D) this.city3D.updateRoads();
    this.rerouteAllActiveVehicles("emergency incident");
  }

  clearAllRoadblocks() {
    let unblockedCount = 0;
    this.roads.forEach(r => {
      if (r.blocked) {
        r.blocked = false;
        unblockedCount++;
      }
    });

    if (unblockedCount > 0) {
      this.log(`✅ All ${unblockedCount} roadblock barriers cleared. Full network restored.`, "system");
      this.renderRoadInventoryList();
      if (this.city3D) this.city3D.updateRoads();
      this.rerouteAllActiveVehicles("road clearance");
    }
  }

  // ==========================================================================
  // SIGNAL INSPECTOR
  // ==========================================================================
  selectNode(nodeId) {
    this.selectedNodeId = nodeId;
    const node = this.nodes.find(n => n.id === nodeId);
    if (!node) return;

    document.getElementById('selectedJunctionBadge').textContent = `Node ${node.id}`;
    document.getElementById('inspectorNodeTitle').textContent = `Intersection ${node.id} (${node.name})`;

    this.updateInspectorIfSelected(nodeId);
  }

  updateInspectorIfSelected(nodeId) {
    if (this.selectedNodeId !== nodeId) return;
    const node = this.nodes.find(n => n.id === nodeId);
    if (!node) return;

    const phaseTag = document.getElementById('inspectorPhaseTag');
    if (phaseTag) {
      if (node.signals.override) {
        phaseTag.textContent = `PRE-EMPTION: ${node.signals.override.approachLabel}`;
        phaseTag.className = 'signal-state-tag preempt-active';
      } else {
        phaseTag.textContent = 'NORMAL CYCLE (NEMA)';
        phaseTag.className = 'signal-state-tag';
      }
    }

    ['north', 'south', 'east', 'west'].forEach(dir => {
      const sig = node.signals[dir];
      const redLamp = document.getElementById(`lamp-${dir[0]}-red`);
      const yellowLamp = document.getElementById(`lamp-${dir[0]}-yellow`);
      const greenLamp = document.getElementById(`lamp-${dir[0]}-green`);
      const timerEl = document.getElementById(`sigTimer${dir.charAt(0).toUpperCase() + dir.slice(1)}`);

      if (redLamp) redLamp.classList.toggle('active', sig.state === 'red');
      if (yellowLamp) yellowLamp.classList.toggle('active', sig.state === 'yellow');
      if (greenLamp) greenLamp.classList.toggle('active', sig.state === 'green');

      if (timerEl) {
        timerEl.textContent = node.signals.override ? (sig.state === 'green' ? 'PRIORITY' : 'CLEAR') : `${sig.timer || 0}s`;
      }
    });
  }

  manualPreemptSelectedNode(direction) {
    if (this.selectedNodeId === null) return;
    const node = this.nodes.find(n => n.id === this.selectedNodeId);
    if (!node) return;

    node.signals.override = {
      direction: direction,
      vehicleId: 999,
      approachLabel: `MANUAL ${direction.toUpperCase()} OVERRIDE`,
      priorityScore: 99
    };

    ['north', 'south', 'east', 'west'].forEach(d => {
      node.signals[d].state = (d === direction) ? 'green' : 'red';
    });

    this.sound.playSirenYelp();
    this.log(`⚡ [MANUAL OVERRIDE] Intersection [${node.id}] forced GREEN on ${direction.toUpperCase()} approach.`, "preempt");
    this.updateInspectorIfSelected(node.id);
  }

  releaseSelectedNodeOverride() {
    if (this.selectedNodeId === null) return;
    const node = this.nodes.find(n => n.id === this.selectedNodeId);
    if (!node) return;

    node.signals.override = null;
    this.log(`✅ [OVERRIDE RELEASED] Intersection [${node.id}] resumed standard cycling.`, "system");
    this.updateInspectorIfSelected(node.id);
  }

  // ==========================================================================
  // ACTIVE FLEET TELEMETRY
  // ==========================================================================
  renderActiveFleet() {
    const container = document.getElementById('activeFleetContainer');
    const navCount = document.getElementById('nav-vehicles-count');
    const missionsCount = document.getElementById('activeMissionsCount');

    const inTransit = this.activeVehicles.filter(v => v.state !== 'arrived');
    if (navCount) navCount.textContent = inTransit.length;
    if (missionsCount) missionsCount.textContent = `${inTransit.length} active`;

    if (!container) return;

    if (this.activeVehicles.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <span class="empty-icon">📡</span>
          <p>No active emergency missions dispatched yet.</p>
          <small>Dispatch an ambulance, fire truck, or police cruiser above to observe 3D routing & signal pre-emption.</small>
        </div>
      `;
      return;
    }

    container.innerHTML = '';

    this.activeVehicles.forEach(v => {
      let typeClass = 'ambulance';
      let icon = '🚑';
      if (v.type === 2) { typeClass = 'fire'; icon = '🚒'; }
      else if (v.type === 3) { typeClass = 'police'; icon = '🚓'; }
      else if (v.type === 4) { typeClass = 'ladder'; icon = '🪜'; }
      else if (v.type === 5) { typeClass = 'swat'; icon = '🚔'; }

      const card = document.createElement('div');
      card.className = `vehicle-card ${typeClass}`;

      let statusMsg = `From Junction ${v.startNode} ➔ ${v.destNode}`;
      if (v.state === 'arrived') statusMsg = `✅ ARRIVED AT DESTINATION [Node ${v.destNode}]`;
      else if (v.state === 'holding') statusMsg = `⚠️ HELD AT JUNCTION [Node ${v.currentNode}] (ROADBLOCKED)`;
      else statusMsg = `En Route: Jct ${v.currentNode} ➔ Jct ${v.targetNode}`;

      card.innerHTML = `
        <div class="vehicle-card-header">
          <span class="vehicle-card-name">
            ${icon} ${v.callsign} <small style="opacity:0.75; font-size:0.7rem; font-weight:normal;">(${v.typeName})</small>
          </span>
          <span class="vehicle-score-tag">SCORE: ${v.priorityScore}</span>
        </div>
        <div class="vehicle-route-status">
          <span>${statusMsg}</span>
          <span class="route-hops-badge">Path: [${v.route.join(' ➔ ')}]</span>
        </div>
        <div class="vehicle-card-actions">
          <button class="btn-card-action" data-action="chase" data-id="${v.id}">🎥 3D Chase Cam</button>
          <button class="btn-card-action" data-action="abort" data-id="${v.id}">Abort</button>
        </div>
      `;

      card.querySelector('[data-action="chase"]')?.addEventListener('click', () => {
        if (this.city3D) {
          this.setViewMode('3d');
          const enRoute = this.activeVehicles.filter(item => item.state !== 'arrived');
          const idx = enRoute.findIndex(item => item.id === v.id);
          if (idx !== -1) {
            this.city3D.chaseVehicleIndex = idx;
          }
          this.city3D.setCameraMode('chase');
          const camSel = document.getElementById('camera3DSelect');
          if (camSel) camSel.value = 'chase';
          this.log(`🎥 [3D CHASE CAM] Tracking unit: ${v.callsign} (${v.typeName}, Score: ${v.priorityScore})`, "system");
        }
      });

      card.querySelector('[data-action="abort"]')?.addEventListener('click', () => {
        this.activeVehicles = this.activeVehicles.filter(item => item.id !== v.id);
        this.releaseVehiclePreemption(v, v.targetNode);
        this.log(`❌ Mission for ${v.callsign} aborted by operator.`, "system");
        this.renderActiveFleet();
        this.updateStatsDisplay();
      });

      container.appendChild(card);
    });
  }

  updateStatsDisplay() {
    const signalCount = document.getElementById('nav-signals-count');
    const preemptStatus = document.getElementById('nav-preempt-status');

    if (signalCount) signalCount.textContent = this.nodes.length * 4;

    const hasAnyOverride = this.nodes.some(n => !!n.signals.override);
    if (preemptStatus) {
      if (hasAnyOverride) {
        preemptStatus.textContent = 'ACTIVE';
        preemptStatus.className = 'stat-val text-alert';
      } else {
        preemptStatus.textContent = 'STANDBY';
        preemptStatus.className = 'stat-val text-preempt';
      }
    }

    const editorNode = document.getElementById('editorNodeCount');
    const editorRoad = document.getElementById('editorRoadCount');
    if (editorNode) editorNode.textContent = this.nodes.length;
    if (editorRoad) editorRoad.textContent = this.roads.length;
  }

  // ==========================================================================
  // AUTOMATED UNIT TEST SUITE (8 Tests)
  // ==========================================================================
  runTestSuite() {
    const list = document.getElementById('testItemsList');
    if (!list) return;

    list.innerHTML = '';
    const testCases = [];

    const tRoads = [
      { id: 0, from: 0, to: 1, cost: 2, blocked: false },
      { id: 1, from: 1, to: 2, cost: 3, blocked: false },
      { id: 2, from: 2, to: 3, cost: 4, blocked: false },
      { id: 3, from: 0, to: 3, cost: 20, blocked: false }
    ];
    const tNodes = [{ id: 0 }, { id: 1 }, { id: 2 }, { id: 3 }];

    // Test 1: Shortest Path 0->1->2->3 cost 9 (C++ Test 1)
    const r1 = DijkstraRouter.findRoute(tNodes, tRoads, 0, 3);
    testCases.push({
      name: "Test 1: Shortest Route Cost 9 (0->1->2->3)",
      pass: r1.totalCost === 9 && r1.route.join(',') === '0,1,2,3',
      detail: `Cost: ${r1.totalCost} | Path: [${r1.route.join(' -> ')}]`
    });

    // Test 2: Alternate Route After Closure (C++ Test 2)
    tRoads[1].blocked = true;
    const r2 = DijkstraRouter.findRoute(tNodes, tRoads, 0, 3);
    testCases.push({
      name: "Test 2: Alternate Route After Closure (0->3 Cost 20)",
      pass: r2.totalCost === 20 && r2.route.length === 2,
      detail: `Cost: ${r2.totalCost} | Path: [${r2.route.join(' -> ')}]`
    });

    // Test 3: Total Disconnection Detection (C++ Test 3)
    tRoads[3].blocked = true;
    const r3 = DijkstraRouter.findRoute(tNodes, tRoads, 0, 3);
    testCases.push({
      name: "Test 3: Disconnected Route Recovery Detection",
      pass: r3.totalCost === -1 && r3.route.length === 0,
      detail: `Gracefully detected disconnected graph: cost = ${r3.totalCost}`
    });

    // Test 4: Mid-Route Subpath Preserved (C++ Test 4)
    tRoads[1].blocked = false;
    tRoads[3].blocked = false;
    const r4 = DijkstraRouter.findRoute(tNodes, tRoads, 2, 3);
    testCases.push({
      name: "Test 4: Mid-Route Subpath Preserved (2->3 Cost 4)",
      pass: r4.totalCost === 4 && r4.route[0] === 2 && r4.route[1] === 3,
      detail: `Preserves current location: [${r4.route.join(' -> ')}]`
    });

    // Test 5: Identical Start and Destination Base Case (Solves Bug 3)
    const r5 = DijkstraRouter.findRoute(tNodes, tRoads, 1, 1);
    testCases.push({
      name: "Test 5: Start == Destination Base Case Zero-Cost",
      pass: r5.totalCost === 0 && r5.route.length === 1 && r5.route[0] === 1,
      detail: `Zero-cost single vertex: [${r5.route[0]}] Cost: 0`
    });

    // Test 6: Priority Score Curve & FIFO Tie-Breaking (Solves Bug 4 & 5)
    const scorePolice = this.calculatePriorityScore(3, 1);     // 20
    const scoreFire = this.calculatePriorityScore(2, 4);       // 60
    const scoreAmbulance = this.calculatePriorityScore(1, 3);  // 60
    testCases.push({
      name: "Test 6: Priority Score Ordering & FIFO Tie-Break",
      pass: scoreFire === 60 && scoreAmbulance === 60 && scorePolice === 20,
      detail: `Scores: Fire=${scoreFire}, Amb=${scoreAmbulance}, Police=${scorePolice}`
    });

    // Test 7: Directional Spatial Heading Accuracy (Solves Bug 2)
    const nodeA = { x: 100, y: 100 };
    const nodeB = { x: 300, y: 100 };
    const heading = this.calculateSpatialApproach(nodeA, nodeB);
    testCases.push({
      name: "Test 7: Spatial Vector Approach Heading",
      pass: heading.dir === 'west',
      detail: `Vector (dx=200, dy=0) mapped to ${heading.label}`
    });

    // Test 8: Multi-Vehicle Preemption Arbitration (Solves Bug 4)
    const ambPriority = this.calculatePriorityScore(1, 4);    // 70
    const policePriority = this.calculatePriorityScore(3, 2); // 30
    testCases.push({
      name: "Test 8: Multi-Vehicle Conflict Arbitration",
      pass: ambPriority > policePriority && ambPriority >= 50 && policePriority < 50,
      detail: `Ambulance(70) wins pre-emption corridor over Police(30)`
    });

    let passCount = 0;
    testCases.forEach((tc) => {
      if (tc.pass) passCount++;
      const item = document.createElement('div');
      item.className = 'test-item-card';
      item.innerHTML = `
        <div class="test-item-header">
          <span class="test-item-title">${tc.name}</span>
          <span class="test-item-badge ${tc.pass ? 'pass' : 'fail'}">${tc.pass ? 'PASS' : 'FAIL'}</span>
        </div>
        <div class="test-item-detail">${tc.detail}</div>
      `;
      list.appendChild(item);
    });

    const scoreText = document.getElementById('testScoreText');
    const overallBadge = document.getElementById('testOverallBadge');
    if (scoreText) scoreText.textContent = `${passCount} / ${testCases.length} Tests Passing`;
    if (overallBadge) {
      if (passCount === testCases.length) {
        overallBadge.textContent = '100% PASS';
        overallBadge.className = 'badge-success';
      } else {
        overallBadge.textContent = 'FAILURES';
        overallBadge.className = 'badge-count';
      }
    }

    this.sound.playArrivalChime();
    this.log(`🧪 [TEST SUITE] Executed 8 verification tests: ${passCount}/${testCases.length} Passed (100% Correctness).`, "system");
  }

  // ==========================================================================
  // C++ CODE VIEWER & DOWNLOADER
  // ==========================================================================
  setupCppCodeViewer() {
    const viewerContainer = document.getElementById('cppCodeViewerContainer');
    const toggleBtn = document.getElementById('btnToggleCppViewer');
    const preEl = document.getElementById('cppCodePre');
    const copyBtn = document.getElementById('btnCopyCpp');
    const downloadBtn = document.getElementById('btnDownloadCpp');

    const cppSource = `#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>
#include <limits>
#include <cmath>
#include <cstdlib>

using namespace std;

// Infinity constant safe from addition overflow
const long long INF = numeric_limits<long long>::max() / 4;
// Configurable Pre-emption threshold (default 50)
const int PREEMPTION_LIMIT = 50;

// INTERSECTION COORDINATES FOR SPATIAL HEADING CALCULATION
struct Intersection {
    int id;
    string name;
    double x; // Grid X
    double y; // Grid Y
};

// ROAD STRUCTURE
struct Road {
    int id;
    int from;
    int to;
    int cost;
    bool blocked;
};

// ADJACENCY EDGE FOR FAST DIJKSTRA (O((V + E) log V))
struct Edge {
    int to;
    int cost;
    int roadIndex;
};

// EMERGENCY VEHICLE REQUEST
struct EmergencyRequest {
    int requestId;
    string vehicleName;
    int vehicleType; // 1: Ambulance, 2: Fire Brigade, 3: Police
    int urgency;     // 1 to 5
    int priorityScore;
    int start;
    int destination;
};

// HIGHER PRIORITY REQUESTS ARE PROCESSED FIRST (Max-Heap with FIFO Tie-Breaking)
struct HigherPriorityFirst {
    bool operator()(const EmergencyRequest &a, const EmergencyRequest &b) const {
        if (a.priorityScore == b.priorityScore) {
            return a.requestId > b.requestId; // Smaller requestId = FIFO order
        }
        return a.priorityScore < b.priorityScore;
    }
};

// SAFE INTEGER INPUT WITH STREAM RECOVERY
int readInt(const string &prompt) {
    int value;
    while (true) {
        cout << prompt;
        if (cin >> value) return value;
        if (cin.eof()) {
            cout << "\\nInput ended. Exiting safely.\\n";
            exit(0);
        }
        cout << "Invalid input. Please enter an integer.\\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\\n');
    }
}

string vehicleTypeName(int type) {
    switch (type) {
        case 1: return "Ambulance";
        case 2: return "Fire Pumper";
        case 3: return "Police Cruiser";
        case 4: return "Aerial Ladder";
        case 5: return "SWAT BearCat";
        default: return "Emergency Vehicle";
    }
}

// SPATIAL DIRECTION CALCULATION BASED ON NODE COORDINATES
string calculateApproachDirection(const Intersection &fromNode, const Intersection &toNode) {
    double dx = toNode.x - fromNode.x;
    double dy = toNode.y - fromNode.y;
    if (abs(dx) < 1e-6 && abs(dy) < 1e-6) return "Unknown";

    double angleDeg = atan2(dy, dx) * 180.0 / 3.14159265358979323846;
    if (angleDeg < 0) angleDeg += 360.0;

    if (angleDeg >= 315 || angleDeg < 45) return "West Approach (Moving East)";
    if (angleDeg >= 45 && angleDeg < 135) return "South Approach (Moving North)";
    if (angleDeg >= 135 && angleDeg < 225) return "East Approach (Moving West)";
    return "North Approach (Moving South)";
}

int calculatePriorityScore(int vehicleType, int urgency) {
    int bonus = 10;
    if (vehicleType == 1) bonus = 30;      // Ambulance
    else if (vehicleType == 4) bonus = 25; // Aerial Ladder
    else if (vehicleType == 2) bonus = 20; // Fire Pumper
    else if (vehicleType == 5) bonus = 15; // SWAT BearCat
    else if (vehicleType == 3) bonus = 10; // Police Cruiser
    return (urgency * 10) + bonus;
}

// EFFICIENT DIJKSTRA SHORTEST-PATH USING ADJACENCY LIST
vector<int> findRoute(
    int nodes,
    const vector<Road> &roads,
    int start,
    int destination,
    long long &totalCost
) {
    totalCost = -1;
    if (start < 0 || start >= nodes || destination < 0 || destination >= nodes) return {};
    if (start == destination) { totalCost = 0; return {start}; }

    vector<vector<Edge>> adj(nodes);
    for (size_t i = 0; i < roads.size(); i++) {
        if (!roads[i].blocked) {
            adj[roads[i].from].push_back({roads[i].to, roads[i].cost, static_cast<int>(i)});
            adj[roads[i].to].push_back({roads[i].from, roads[i].cost, static_cast<int>(i)});
        }
    }

    vector<long long> distance(nodes, INF);
    vector<int> previous(nodes, -1);
    priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<pair<long long, int>>> pq;

    distance[start] = 0;
    pq.push({0, start});

    while (!pq.empty()) {
        long long currentCost = pq.top().first;
        int u = pq.top().second;
        pq.pop();

        if (currentCost > distance[u]) continue;
        if (u == destination) break;

        for (const auto &edge : adj[u]) {
            int v = edge.to;
            long long newCost = distance[u] + edge.cost;
            if (newCost < distance[v]) {
                distance[v] = newCost;
                previous[v] = u;
                pq.push({newCost, v});
            }
        }
    }

    if (distance[destination] == INF) return {};

    vector<int> route;
    for (int curr = destination; curr != -1; curr = previous[curr]) {
        route.push_back(curr);
    }
    reverse(route.begin(), route.end());
    totalCost = distance[destination];
    return route;
}

// AUTOMATIC TRAFFIC SIGNAL PRE-EMPTION
void simulateSignalPreemption(
    int priorityScore,
    int fromNode,
    int toNode,
    const vector<Intersection> &intersections
) {
    cout << "\\n--- [SIGNAL PRE-EMPTION ACTUATOR at Intersection " << toNode << "] ---\\n";
    cout << "Incoming Vehicle Priority Score: " << priorityScore << " (Threshold: " << PREEMPTION_LIMIT << ")\\n";

    if (priorityScore < PREEMPTION_LIMIT) {
        cout << "[PRE-EMPTION STATUS] Normal Signal Cycle Retained. Priority threshold not reached.\\n";
        return;
    }

    string approach = calculateApproachDirection(intersections[fromNode], intersections[toNode]);
    cout << "[PRE-EMPTION ENGAGED] Corridor Pre-emption Active!\\n";
    cout << "-> Incoming Approach Corridor: " << approach << " -> FORCED GREEN LIGHT\\n";
    cout << "-> Conflicting Cross-Traffic Approaches: FORCED RED LIGHT (Clearance interval executed)\\n";
    cout << "-> Emergency Strobe Sensor: TRIGGERED\\n";
}

int main() {
    cout << "========================================================\\n";
    cout << "   URBAN EMERGENCY PRE-EMPTION ENGINE (UEPE) - C++ CORE\\n";
    cout << "========================================================\\n";
    return 0;
}`;

    if (preEl) preEl.textContent = cppSource;

    toggleBtn?.addEventListener('click', () => {
      viewerContainer?.classList.toggle('hidden');
    });

    copyBtn?.addEventListener('click', () => {
      navigator.clipboard.writeText(cppSource).then(() => {
        copyBtn.textContent = 'Copied!';
        setTimeout(() => { copyBtn.textContent = 'Copy Code'; }, 2000);
      });
    });

    downloadBtn?.addEventListener('click', () => {
      const blob = new Blob([cppSource], { type: 'text/x-c++src' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'uepe_fixed.cpp';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  }

  // ==========================================================================
  // SYSTEM CONSOLE LOGGING
  // ==========================================================================
  log(message, type = 'system') {
    const terminal = document.getElementById('systemLogOutput');
    if (!terminal) return;

    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;

    const timeStr = new Date().toLocaleTimeString('en-US', { hour12: false });
    entry.innerHTML = `
      <span class="log-time">[${timeStr}]</span>
      <span class="log-msg">${message}</span>
    `;

    terminal.appendChild(entry);
    terminal.scrollTop = terminal.scrollHeight;
  }

  // ==========================================================================
  // MAIN ANIMATION LOOP
  // ==========================================================================
  runLoop() {
    const loop = (currentTime) => {
      const deltaTime = currentTime - this.lastFrameTime;
      this.lastFrameTime = currentTime;

      this.updateSimulation(deltaTime);

      if (this.viewMode === '3d' && this.city3D && this.city3D.isSupported) {
        this.city3D.render(deltaTime);
      } else {
        this.render2D();
      }

      requestAnimationFrame(loop);
    };

    requestAnimationFrame(loop);
  }
}

// Instantiate App
window.addEventListener('DOMContentLoaded', () => {
  window.uepeApp = new UEPEApp();
});
