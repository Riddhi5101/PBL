# Urban Emergency Pre-Emption Engine (UEPE) - 3D
### NextGen Intelligent Traffic Management System (ITMS) • 3D Emergency Routing & Signal Pre-Emption

A full-stack interactive 3D WebGL application and corrected, high-performance C++ simulation engine for prioritizing emergency response vehicles (ambulances, fire engines, police interceptors) through urban road networks via dynamic shortest-path routing, real-time mid-transit obstruction rerouting, and spatial traffic signal pre-emption.

---

## 🚀 Quick Start: Launching the 3D Website

The application is completely self-contained and requires no build tools or package managers.

### Option 1: Open Directly in Your Browser
Double-click or open `index.html` in any modern web browser (Google Chrome, Microsoft Edge, Mozilla Firefox, Brave, Safari):
```
file:///C:/Users/divya/.gemini/antigravity/scratch/uepe-web/index.html
```

### Option 2: Run via Local HTTP Server (Optional)
```powershell
cd C:\Users\divya\.gemini\antigravity\scratch\uepe-web
python -m http.server 8080
# Open http://localhost:8080 in your browser
```

---

## 🎮 3D WebGL Features & Capabilities

1. **Hardware-Accelerated 3D City (Three.js)**:
   - **Skyscrapers & Architecture**: Multi-story commercial towers with glowing window grids, hospital with rooftop helipad, fire station with rescue bays, and police precinct.
   - **Asphalt Roads & Curbs**: 3D extruded road ribbons with asphalt textures, yellow dashed center dividers, pedestrian crosswalks, and concrete curbs.
   - **3D Traffic Signal Gantries**: Steel poles with cantilever arms holding functional 3-aspect signal heads (Red, Yellow, Green) that cast real emissive light onto the street.
   - **3D Construction Hazard Barricades**: When a road is blocked, 3D A-frame hazard barricades with orange/white warning stripes and flashing amber warning strobes drop down across the lanes!

2. **3D Procedural Emergency Vehicles (5 Distinct Classes)**:
   - 🚑 **Ambulance (EMS Medic)**: High-top emergency medical box body with red crosses, front windshield, 4 rotating wheels, and flashing red/white rooftop lightbars with dynamic point lights. (+30 Priority Bonus)
   - 🚒 **Fire Pumper (Rescue Engine)**: Heavy rescue crimson body, chrome front grille and pump panels, roof water monitor deck gun, rear hosebed, 6 rotating wheels, dual red/amber rotating beacons. (+20 Priority Bonus)
   - 🚓 **Police Cruiser (Pursuit Patrol)**: Tactical black-and-white pursuit vehicle with front push bumper, low-profile high-speed blue/red pursuit strobe lightbar, 4 wheels. (+10 Priority Bonus)
   - 🪜 **Aerial Ladder Truck (Heavy Rescue)**: Extended 15.5-meter chassis, elevated cab, 360° rotating turntable pedestal, articulated 13.5-meter silver telescopic ladder on roof, outrigger stabilizers, 6 wheels (dual rear bogie), red/amber beacons. (+25 Priority Bonus)
   - 🚔 **SWAT BearCat (Tactical Armored Vehicle)**: Matte tactical black armored faceted hull, narrow ballistic slit viewports, reinforced steel battering ram bumper, roof observation gunner cupola turret, 4 heavy combat wheels, blue/cyan stealth perimeter strobes. (+15 Priority Bonus)

3. **Multi-Vehicle Fleet Dispatch & Mixed Task Force Builder**:
   - **Custom Fleet Quantity (1 to 10 Units)**: Dispatch single units or entire multi-vehicle convoys with staggered start times to avoid geometric overlap.
   - **Mixed Fleet Task Force Builder**: Assemble mixed tactical convoys (e.g. 2 Ambulances + 1 Ladder + 1 Engine + 2 Cruisers + 1 BearCat) converging on an incident junction with either Distributed Station or Single Staging deployment.
   - **Pre-Configured Scenarios**: Instant 1-click deployments:
     - 🚨 *Code-3 Rapid Response (3 Units: 1 Medic, 1 Engine, 1 Cruiser)*
     - 🚑 *Medical Surge (3 Ambulances converging on Trauma Center)*
     - 🚒 *3-Alarm Structure Fire (4 Units: 2 Engines, 1 Ladder, 1 Medic)*
     - 🚔 *SWAT Tactical Siege (5 Units: 2 BearCats, 2 Cruisers, 1 Medic)*
     - 💥 *Highway Multi-Vehicle Pileup (6 Units across grid)*
     - 🎲 *Random Citywide Mixed Fleet (6 diverse units)*

4. **Smooth Dynamic Mid-Transit Obstruction Rerouting ("Road Beech Mai Block")**:
   - **Physical Position Continuity (Zero Teleportation)**: When an upcoming road is blocked while a vehicle is driving between junctions, the engine recalculates Dijkstra from the *upcoming junction* and smoothly updates the trajectory ahead without resetting `progress`.
   - **Hazard On Active Road (Smooth 180° Emergency U-Turn)**: If the road the vehicle is *currently on* gets blocked mid-transit:
     - If before the midpoint (`progress < 0.6`), vehicle executes an emergency 180° turn back towards the start junction (`progress = 1.0 - progress`) and detours via an alternate corridor.
     - If past the midpoint (`progress >= 0.6`), vehicle clears the junction ahead and diverts from there.
   - **Automatic Obstruction Recovery**: If all roads to the destination are severed, the vehicle safely slows down, sounds a hazard alert, and enters `HOLDING` state. As soon as any road is reopened or cleared, all holding vehicles automatically recalculate Dijkstra and resume transit seamlessly!

5. **3D Holographic Pre-Emption Corridor & Priority Arbitration**:
   - Dynamic glowing neon laser corridor ribbons projected along the street surface color-coded by vehicle class (Green=Ambulance, Red=Fire, Cyan=Police, Gold=Ladder, Purple=SWAT).
   - Real-time **Conflict Arbitration HUD**: When multiple vehicles arrive at the same intersection, the engine arbitrates right-of-way based on priority scores and FIFO queueing, displaying an active arbitration banner while giving forced green to the winner and all-red to cross traffic.

4. **Multi-Camera 3D Director**:
   - 🎥 **Orbit Mode (Free Cam)**: Rotate with left-click, pan with right-click, zoom with scroll wheel.
   - 🏎️ **Chase Cam (Follow Vehicle)**: Locks directly behind the dispatched emergency vehicle in third person, banking as it steers through street corners!
   - 🚁 **Drone Cam (Isometric Tactical)**: High-altitude angled tactical overview.
   - 📹 **CCTV Cam (Junction Security Cam)**: Street-level security camera perched on the traffic light mast looking down into the selected intersection.

5. **Day / Night Lighting Modes**:
   - 🌙 **Night Neon Mode (Default)**: Deep dark sky, streetlights, glowing window grids, and reflections of emergency lights on wet asphalt.
   - ☀️ **Daylight Metropolis Mode**: Bright directional sunlight, soft ambient illumination, and crisp shadows.

6. **Interactive 3D Raycasting**:
   - Click any road in 3D to open the Road Congestion & Blockage modal (set travel cost, block/reopen).
   - Click any junction in 3D to inspect its 4-way traffic signals or snap the CCTV camera.
   - Click any vehicle in 3D to latch the Chase Camera onto it!

7. **Dual-View Switcher**:
   - Switch between **`[🎮 3D City View]`** and **`[🗺️ 2D Tactical View]`** with a single click.

---

## 🐞 Bugs Identified in the Original Code & How They Were Solved

Below is a detailed engineering analysis of the bugs identified in the original C++ codebase and how each was resolved in both `uepe_fixed.cpp` and `app.js`:

| Bug # | Original Code Flaw | Impact / Severity | Corrected Solution |
|---|---|---|---|
| **Bug 1: $O(V \cdot E)$ Linear Edge Scan in Dijkstra** | At each popped node, the code looped through all roads in a flat array (`for (size_t i = 0; i < roads.size(); i++)`). | High: With 100 nodes and 10,000 edges, runs up to 1,000,000 edge checks. Unscalable for real-time dispatch. | Replaced with an **Adjacency List** (`vector<vector<Edge>> adj`) and min-heap, reducing traversal to optimal $O((V + E) \log V)$. |
| **Bug 2: Detached Traffic Signal Pre-emption** | In `simulateSignal`, the program prompted the user to type a random number 1–4 ("Enter direction"). The vehicle moved through all remaining intersections with **zero** pre-emption! | Critical: Signal pre-emption was a static manual illusion and disconnected from map geometry and ongoing vehicle movement. | Implemented **Autonomous Spatial Vector Actuation**: as vehicle travels, engine calculates the approach vector heading $\theta = \operatorname{atan2}(\Delta y, \Delta x)$ towards the upcoming junction. Green corridor is granted to incoming approach; conflicting cross-streets get Yellow clearance then All-Red lock. |
| **Bug 3: Start Node Equals Destination Crash** | When `currentLocation == destination`, reconstructed route array of length 1 triggered `currentRoute.size() < 2` failure in step navigation. | Medium: Prevented clean termination and falsely claimed "No route available". | Handled base case cleanly: if `start == dest`, returns single-vertex route `[start]` with `totalCost = 0` and marks arrival. |
| **Bug 4: Sequential Single-Vehicle Blocking Loop** | Outer loop `while (!requests.empty())` completely blocked until the current vehicle reached its destination or was aborted. | High: City could not simulate multiple emergency dispatches at once. | Implemented **Concurrent Multi-Vehicle Simulation** with priority arbitration (Opticom / NTCIP 1202 standard). If two emergency vehicles approach the same junction, the higher priority score receives the green corridor. |
| **Bug 5: Premature Early Return in Road Updates** | In `updateRoadsAndReroute`, if a road was already blocked or open, it returned `true` immediately without recalculating routes. | Medium: State desynchronization between road matrix and active routes. | Ensured road state toggles trigger immediate graph topology updates, alternative path re-evaluations, and mid-transit rerouting. |
| **Bug 6: Low-Urgency Ambulance Discarded** | Priority formula: `urgency * 10 + bonus`. Ambulance bonus = 30. Urgency 1 produced $10 + 30 = 40$. Because threshold was 50, an active ambulance was denied pre-emption. | High: Real-world emergency ambulances should receive signal priority. | Balanced urgency curve and added tiered clearance stages, ensuring active dispatches receive appropriate priority levels. |

---

## 🛠️ Compiling and Running the Corrected C++ Engine

The corrected C++ code is located in `uepe_fixed.cpp`.

```bash
# Compile with GCC / MinGW:
g++ -O3 -std=c++17 uepe_fixed.cpp -o uepe.exe

# Compile with Clang:
clang++ -O3 -std=c++17 uepe_fixed.cpp -o uepe.exe

# Compile with MSVC (Visual Studio):
cl /O2 /std:c++17 uepe_fixed.cpp /Fe:uepe.exe

# Execute:
./uepe.exe
```

---

## 📁 Project Structure

```
uepe-web/
├── index.html        # Modern 3D/2D UI with Three.js WebGL viewport
├── style.css         # Glassmorphism, cyber-tactical layout, signal heads
├── app.js            # City3DRenderer, Dijkstra Engine, Signal Actuator, Audio
├── uepe_fixed.cpp    # Corrected, high-performance C++ core implementation
└── README.md         # Full project documentation & bug audit
```
